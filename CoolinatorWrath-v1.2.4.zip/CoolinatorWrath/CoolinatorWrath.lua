-- Coolinator-Wrath
-- Wrath 3.3.5-native cooldown and aura tracker inspired by Coolinator.
-- Version: 1.2.4

local ADDON = "CoolinatorWrath"
-- 3.3.5 / Lua compatibility: some older addon paths may still expect math.mod.
if not math.mod then math.mod = math.fmod end

local CW = CreateFrame("Frame", "CoolinatorWrathFrame", UIParent)
_G[ADDON] = CW

local DEFAULTS = {
    enabled = true,
    locked = false,
    scale = 1,
    iconSize = 36,
    spacing = 4,
    maxColumns = 8,
    showReady = false,
    showTimers = true,
    smartProc = true,
    procGlow = true,
    procPulse = true,
    procAlert = true,
    procSound = false,
    procSoundMode = "RAID",
    procSoundProcMode = "RAID",
    procSoundBuffMode = "TELL",
    procSoundExecuteMode = "LEVEL",
    soundProfile = "Default",
    keybindOverlay = true,
    procRecommendationText = true,
    equipmentSlots = {},
    disabledProcs = {},
    procDebug = false,
    autoProcAlert = true,
    procGlowStyle = 1,
    timerScale = 1.2,
    procPopout = false,
    hotbarGlow = false,
    alertSplit = true,
    suspendAlertsOnMap = true,
    profiles = {},
    activeProfile = "Default",
    growDirection = 'RIGHT',
    designerMode = false,
    editDropZone = true,
    emptySlotDrop = true,
    freeform = true,
    snap = 4,
    iconPositions = {},
    addSlotPosition = { x = 0, y = 0 },
    addSlotAuto = true,
    canvasWidth = 600,
    canvasHeight = 400,
    point = "CENTER",
    relativePoint = "CENTER",
    x = 0,
    y = -180,
    spells = {},
    items = {},
    auras = {},
}

local DB
local buttons = {}
local addSlot
local objects = {}
local elapsedSinceUpdate = 0
local testMode = false
local procTestMode = false
local dragging = false
local draggingButton = nil
local dragStartX, dragStartY
local ConfigFrame
local dragHandle
local lastVisibleKey = ""
local dropZone
local AddCursorToTracker
local Refresh
local MoveAddSlotToNextOpenSlot
local IsFreeformSlotOccupied
local RemoveTrackedObjectByKey
local UpdateDesignerVisuals
local GetProcAuraForSpell
local FireProcAlert
local ShowSingleProcAlert
local UpdateHotbarProcHighlights
local consumedProcAuras = {}
local currentProcCandidates = {}
local lastAutoProcAlert = {}
local pendingProcAlert = nil
local hotbarButtonCache = nil
local hotbarCacheDirty = true
local lastHotbarCacheBuild = 0
local lastHotbarSignature = ""
local alertCooldowns = {}

local function IsWorldMapOpen()
    return WorldMapFrame and WorldMapFrame.IsShown and WorldMapFrame:IsShown()
end

local function SuppressAlertsForMap()
    -- Beta48: when the world map is open, hide ALL alert decoration layers
    -- so tracker labels/glows and hotbar labels do not draw over the map.
    return DB and DB.suspendAlertsOnMap and IsWorldMapOpen()
end

local function SuppressProcPopoutForMap()
    return SuppressAlertsForMap()
end

local function ApplyTrackerVisibility()
    if not DB then return end
    -- Beta49: when the world map is open, hide the entire tracker canvas.
    -- Earlier map suppression hid alerts/glows, but timer font strings could still draw over the map.
    if DB.enabled and not SuppressAlertsForMap() then
        CW:Show()
    else
        CW:Hide()
    end
end

local function Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff66ccffCoolinator-Wrath:|r " .. tostring(msg))
end

local function CopyDefaults(src, dst)
    if type(dst) ~= "table" then dst = {} end
    for k, v in pairs(src) do
        if type(v) == "table" then
            dst[k] = CopyDefaults(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
    return dst
end

local function Trim(s)
    if not s then return "" end
    return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end


local function NormalizeSavedOptions()
    if not DB then return end
    -- Beta46: keep option fields explicit so toggles survive /reload and older SavedVariables migrate cleanly.
    local optionDefaults = {
        showTimers = true,
        smartProc = true,
        procGlow = true,
        procPulse = true,
        procAlert = true,
        procSound = false,
        procSoundMode = "RAID",
        procSoundProcMode = "RAID",
        procSoundBuffMode = "TELL",
        procSoundExecuteMode = "LEVEL",
        soundProfile = "Default",
        keybindOverlay = true,
        procRecommendationText = true,
        equipmentSlots = {},
        disabledProcs = {},
        procDebug = false,
        autoProcAlert = true,
        procGlowStyle = 1,
        timerScale = 1.2,
        procPopout = false,
        hotbarGlow = false,
        alertSplit = true,
        suspendAlertsOnMap = true,
    }
    for k, v in pairs(optionDefaults) do
        if DB[k] == nil then DB[k] = v end
    end
    if type(DB.profiles) ~= "table" then DB.profiles = {} end
    if type(DB.disabledProcs) ~= "table" then DB.disabledProcs = {} end
    if not DB.activeProfile or DB.activeProfile == "" then DB.activeProfile = "Default" end
end

local function IsNumberString(s)
    return s and s:match("^%d+$") ~= nil
end

local function SavePosition()
    local point, _, relativePoint, x, y = CW:GetPoint(1)
    DB.point = point or "CENTER"
    DB.relativePoint = relativePoint or "CENTER"
    DB.x = x or 0
    DB.y = y or 0
end

local function ApplyPosition()
    CW:ClearAllPoints()
    CW:SetPoint(DB.point or "CENTER", UIParent, DB.relativePoint or "CENTER", DB.x or 0, DB.y or -180)
    CW:SetScale(DB.scale or 1)
end

local function GetSpellKey(input)
    input = Trim(input)
    if input == "" then return nil end
    if IsNumberString(input) then
        local id = tonumber(input)
        local name, _, icon = GetSpellInfo(id)
        if name then return id, name, icon end
        return nil
    end
    local name, _, icon = GetSpellInfo(input)
    if name then return input, name, icon end
    return nil
end

local function GetItemKey(input)
    input = Trim(input)
    if input == "" then return nil end
    if IsNumberString(input) then
        local id = tonumber(input)
        local name, _, _, _, _, _, _, _, _, icon = GetItemInfo(id)
        return id, name or ("Item #" .. id), icon or "Interface\\Icons\\INV_Misc_QuestionMark"
    end
    local name, link, _, _, _, _, _, _, _, icon = GetItemInfo(input)
    if name then return name, name, icon end
    return input, input, "Interface\\Icons\\INV_Misc_QuestionMark"
end

local function FindPlayerAura(auraName)
    local i = 1
    while true do
        local name, rank, icon, count, debuffType, duration, expirationTime = UnitAura("player", i)
        if not name then break end
        if string.lower(name) == string.lower(auraName) then
            return name, icon, count, duration or 0, expirationTime or 0
        end
        i = i + 1
    end
    return nil
end

local function AddObject(kind, key, label, icon)
    table.insert(objects, { kind = kind, key = key, label = label, icon = icon })
end

local function RebuildObjects()
    objects = {}
    for i, v in ipairs(DB.spells) do
        local key, name, icon = GetSpellKey(tostring(v))
        if key then AddObject("spell", key, name, icon) end
    end
    for i, v in ipairs(DB.items) do
        local key, name, icon = GetItemKey(tostring(v))
        if key then AddObject("item", key, name, icon) end
    end
    for i, v in ipairs(DB.equipmentSlots or {}) do
        local slot = tonumber(v)
        if slot then
            local label = (slot == 13 and "Trinket 1") or (slot == 14 and "Trinket 2") or (slot == 10 and "Gloves") or ("Equipment Slot " .. tostring(slot))
            AddObject("equipment", slot, label, "Interface\\Icons\\INV_Misc_QuestionMark")
        end
    end
    for i, v in ipairs(DB.auras) do
        AddObject("aura", v, v, "Interface\\Icons\\INV_Misc_QuestionMark")
    end
end


local function ObjKey(obj)
    if not obj then return "unknown" end
    return tostring(obj.kind or "?") .. ":" .. tostring(obj.key or obj.label or "?")
end

local function SnapValue(v)
    local snap = DB and DB.snap or 0
    if snap and snap > 1 then
        return math.floor((v / snap) + 0.5) * snap
    end
    return v
end

local function SaveIconPosition(button)
    if not button or not button.cwObjKey or not DB then return end
    DB.iconPositions = DB.iconPositions or {}
    local left = button:GetLeft()
    local top = button:GetTop()
    local parentLeft = CW:GetLeft()
    local parentTop = CW:GetTop()
    if not left or not top or not parentLeft or not parentTop then return end

    local x = SnapValue(left - parentLeft)
    local y = SnapValue(top - parentTop)
    DB.iconPositions[button.cwObjKey] = { x = x, y = y }
end

local function ApplyFreeformPosition(frame, key, fallbackIndex)
    local size = DB.iconSize or 36
    local spacing = DB.spacing or 4
    local pos = key and DB.iconPositions and DB.iconPositions[key]
    local x, y

    if pos then
        x = pos.x or 0
        y = pos.y or 0
    else
        local n = fallbackIndex - 1
        x = n * (size + spacing)
        y = 0
    end

    frame:ClearAllPoints()
    frame:SetPoint("TOPLEFT", CW, "TOPLEFT", x, y)
    frame:SetWidth(size)
    frame:SetHeight(size)
end

local function GetNextFreeformSlotIndex()
    local count = 0
    for _, b in ipairs(buttons) do
        if b:IsShown() then count = count + 1 end
    end
    return count + 1
end


local function ForceStopDragging()
    if draggingButton then
        local b = draggingButton
        local wasIconDrag = b.cwObjKey ~= nil
        local oldX = b.cwDragStartX
        local oldY = b.cwDragStartY

        draggingButton = nil
        if b.StopMovingOrSizing then b:StopMovingOrSizing() end
        SaveIconPosition(b)

        -- If an icon is pulled out of its natural/default spot, the + slot
        -- should move to the spot that icon just vacated. Do not scan the
        -- entire canvas here; scanning can make + jump to a distant old slot.
        if wasIconDrag and DB and DB.freeform and oldX ~= nil and oldY ~= nil then
            DB.addSlotPosition = DB.addSlotPosition or { x = 0, y = 0 }
            DB.addSlotPosition.x = SnapValue(oldX)
            DB.addSlotPosition.y = SnapValue(oldY)
            DB.addSlotAuto = true
            if addSlot then
                addSlot:ClearAllPoints()
                addSlot:SetPoint("TOPLEFT", CW, "TOPLEFT", DB.addSlotPosition.x, DB.addSlotPosition.y)
            end
        end
    end

    if dragging then
        dragging = false
        if CW.StopMovingOrSizing then CW:StopMovingOrSizing() end
        SavePosition()
    end
end


local function GetTrackedObjectCount()
    local n = 0
    if DB then
        n = n + table.getn(DB.spells or {})
        n = n + table.getn(DB.items or {})
        n = n + table.getn(DB.auras or {})
    end
    return n
end

local function AdvanceAddSlotLinear()
    if not DB then return end
    local size = DB.iconSize or 36
    local spacing = DB.spacing or 4
    DB.addSlotPosition = DB.addSlotPosition or { x = 0, y = 0 }
    DB.addSlotPosition.x = SnapValue((DB.addSlotPosition.x or 0) + size + spacing)
    DB.addSlotPosition.y = SnapValue(DB.addSlotPosition.y or 0)
end

local function AdvanceAddSlotFromCurrent()
    if not DB then return end
    local size = DB.iconSize or 36
    local spacing = DB.spacing or 4
    DB.addSlotPosition = DB.addSlotPosition or { x = 0, y = 0 }

    -- After a drop, the new icon is placed exactly where the + was.
    -- The + should then advance from THAT spot, not rescan the whole
    -- canvas. Rescanning is what made + teleport back to the moved icon
    -- at the top of the layout.
    local x = SnapValue((DB.addSlotPosition.x or 0) + size + spacing)
    local y = SnapValue(DB.addSlotPosition.y or 0)

    -- Skip over occupied spots on the same visual row, but stay with the
    -- current group/line. Do not jump to the first global open slot.
    local guard = 0
    while IsFreeformSlotOccupied and IsFreeformSlotOccupied(x, y) and guard < 32 do
        x = SnapValue(x + size + spacing)
        guard = guard + 1
    end

    DB.addSlotPosition.x = x
    DB.addSlotPosition.y = y
    DB.addSlotAuto = true
end

local function AdvanceAddSlot()
    if DB and DB.freeform then
        AdvanceAddSlotFromCurrent()
        return
    end
    AdvanceAddSlotLinear()
end

local function SaveAddSlotPosition(manual)
    if not addSlot or not DB then return end
    local left = addSlot:GetLeft()
    local top = addSlot:GetTop()
    local parentLeft = CW:GetLeft()
    local parentTop = CW:GetTop()
    if not left or not top or not parentLeft or not parentTop then return end
    DB.addSlotPosition = DB.addSlotPosition or { x = 0, y = 0 }
    DB.addSlotPosition.x = SnapValue(left - parentLeft)
    DB.addSlotPosition.y = SnapValue(top - parentTop)
    if manual then DB.addSlotAuto = false end
end


IsFreeformSlotOccupied = function(slotX, slotY)
    if not DB or not DB.iconPositions then return false end
    local size = DB.iconSize or 36
    local tolerance = math.max(6, size * 0.45)

    for key, pos in pairs(DB.iconPositions) do
        if type(pos) == "table" and pos.x and pos.y then
            if math.abs((pos.x or 0) - slotX) <= tolerance and math.abs((pos.y or 0) - slotY) <= tolerance then
                return true
            end
        end
    end
    return false
end

local function GetFreeformGridSlot(index)
    local size = DB and DB.iconSize or 36
    local spacing = DB and DB.spacing or 4
    local cols = DB and DB.maxColumns or 8
    if not cols or cols < 1 then cols = 8 end

    local n = math.max(0, (index or 1) - 1)
    local row = math.floor(n / cols)
    local col = math.mod(n, cols)
    return SnapValue(col * (size + spacing)), SnapValue(-row * (size + spacing))
end

MoveAddSlotToNextOpenSlot = function()
    if not DB or not DB.freeform then return end
    DB.addSlotPosition = DB.addSlotPosition or { x = 0, y = 0 }
    DB.addSlotAuto = true

    -- Scan the natural canvas cells and put the + in the first empty one.
    -- This prevents a dragged icon from leaving a permanent hole that makes
    -- every future icon march farther right.
    local tracked = table.getn(DB.spells or {}) + table.getn(DB.items or {}) + table.getn(DB.auras or {})
    local maxScan = math.max(32, tracked + 16)
    for i = 1, maxScan do
        local x, y = GetFreeformGridSlot(i)
        if not IsFreeformSlotOccupied(x, y) then
            DB.addSlotPosition.x = x
            DB.addSlotPosition.y = y
            if addSlot then
                addSlot:ClearAllPoints()
                addSlot:SetPoint("TOPLEFT", CW, "TOPLEFT", x, y)
            end
            return
        end
    end

    -- Extremely defensive fallback: append after everything if somehow every
    -- scanned slot is occupied.
    local x, y = GetFreeformGridSlot(tracked + 1)
    DB.addSlotPosition.x = x
    DB.addSlotPosition.y = y
    if addSlot then
        addSlot:ClearAllPoints()
        addSlot:SetPoint("TOPLEFT", CW, "TOPLEFT", x, y)
    end
end

local function NormalizeAddSlotAfterRemoval()
    if not DB then return end
    -- Beta50 hotfix: equipment-slot removals use the same freeform cleanup path as
    -- normal tracked icons. Without this, the icon disappears but the + slot can
    -- remain stranded to the right, leaving an empty visual gap.
    if DB.freeform and MoveAddSlotToNextOpenSlot then
        MoveAddSlotToNextOpenSlot()
    else
        local size = DB.iconSize or 36
        local spacing = DB.spacing or 4
        DB.addSlotPosition = DB.addSlotPosition or { x = 0, y = 0 }
        DB.addSlotPosition.x = SnapValue(GetTrackedObjectCount() * (size + spacing))
        DB.addSlotPosition.y = SnapValue(0)
    end
end


local function UpdateDesignerVisuals(frame)
    if not frame then return end
    if DB and not DB.locked then
        if frame.SetBackdrop then
            frame:SetBackdrop({
                edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                edgeSize = 10,
                insets = { left = 1, right = 1, top = 1, bottom = 1 }
            })
            frame:SetBackdropBorderColor(0.45, 0.8, 1, 0.95)
        end
        if frame.SetAlpha then frame:SetAlpha(0.92) end
    else
        if frame.SetBackdrop then frame:SetBackdrop(nil) end
        if frame.SetAlpha then frame:SetAlpha(1) end
    end
end


local function FormatCooldownTime(remaining)
    remaining = tonumber(remaining or 0) or 0
    if remaining <= 0 then return "" end
    if remaining >= 3600 then
        return tostring(math.ceil(remaining / 3600)) .. "h"
    elseif remaining >= 60 then
        return tostring(math.ceil(remaining / 60)) .. "m"
    else
        return tostring(math.ceil(remaining))
    end
end

local function SafeSetScale(frame, scale)
    if frame and frame.SetScale then
        frame:SetScale(scale)
    end
end

local function IsTargetInExecuteRange()
    if not UnitExists or not UnitHealth or not UnitHealthMax then return false end
    if not UnitExists("target") then return false end
    if UnitIsDeadOrGhost and UnitIsDeadOrGhost("target") then return false end
    if UnitCanAttack and not UnitCanAttack("player", "target") then return false end
    local maxHealth = UnitHealthMax("target") or 0
    if maxHealth <= 0 then return false end
    local pct = (UnitHealth("target") or 0) / maxHealth
    return pct <= 0.20
end

local EXECUTE_SPELLS_BY_CLASS = {
    PALADIN = { "Hammer of Wrath" },
    WARRIOR = { "Execute" },
    HUNTER = { "Kill Shot" },
}

local EXECUTE_ICON_FALLBACKS = {
    ["Hammer of Wrath"] = "Interface\Icons\Ability_ThunderClap",
    ["Execute"] = "Interface\Icons\INV_Sword_48",
    ["Kill Shot"] = "Interface\Icons\Ability_Hunter_Assassinate2",
}

local function GetPlayerClassFile()
    if UnitClass then
        local _, classFile = UnitClass("player")
        return classFile
    end
    return nil
end

local function IsExecuteSpellExplicitlyTracked(spellName)
    if not DB or not spellName then return false end
    local wanted = string.lower(tostring(spellName))
    for _, v in ipairs(DB.spells or {}) do
        if string.lower(tostring(v)) == wanted then return true end
        local key, name = GetSpellKey(tostring(v))
        if name and string.lower(tostring(name)) == wanted then return true end
        if key and string.lower(tostring(key)) == wanted then return true end
    end
    return false
end

local function ResolveExecuteSpellInfo(spellName)
    local resolved, rank, icon
    if GetSpellInfo then
        resolved, rank, icon = GetSpellInfo(spellName)
    end
    -- Beta50c: execute abilities must survive spec/action-bar swaps on fussy 3.3.5/private clients.
    -- If the class says this is the execute spell, keep the proc candidate alive even when
    -- GetSpellInfo(name) temporarily fails or the spell is only present through a macro/button.
    if not resolved and (EXECUTE_ICON_FALLBACKS[spellName] or IsExecuteSpellExplicitlyTracked(spellName)) then
        resolved = spellName
    end
    icon = icon or EXECUTE_ICON_FALLBACKS[spellName] or "Interface\Icons\INV_Misc_QuestionMark"
    return resolved, icon
end

local SMART_PROC_MAP = {
    -- PALADIN
    ["the art of war"] = { spells = { "Exorcism", "Flash of Light" } },
    ["art of war"] = { spells = { "Exorcism", "Flash of Light" } },
    ["infusion of light"] = { spells = { "Holy Light", "Flash of Light" } },
    ["lights grace"] = { spells = { "Holy Light" } },
    ["light's grace"] = { spells = { "Holy Light" } },

    -- MAGE
    ["hot streak"] = { spells = { "Pyroblast" } },
    ["missile barrage"] = { spells = { "Arcane Missiles" } },
    ["brain freeze"] = { spells = { "Frostfire Bolt", "Fireball" } },
    ["fingers of frost"] = { spells = { "Ice Lance", "Deep Freeze" } },
    ["firestarter"] = { spells = { "Flamestrike" } },
    ["impact"] = { spells = { "Fire Blast" } },
    ["arcane potency"] = { autoAlert = false, spells = { "Arcane Blast", "Arcane Missiles", "Arcane Barrage" } },
    ["presence of mind"] = { autoAlert = false, spells = { "Arcane Blast", "Pyroblast", "Fireball", "Frostbolt", "Frostfire Bolt", "Polymorph" } },

    -- DEATH KNIGHT
    ["killing machine"] = { spells = { "Frost Strike", "Howling Blast", "Icy Touch" } },
    ["rime"] = { spells = { "Howling Blast" } },
    ["freezing fog"] = { spells = { "Howling Blast" } },
    ["sudden doom"] = { spells = { "Death Coil" } },

    -- WARRIOR
    ["sudden death"] = { spells = { "Execute" } },
    ["bloodsurge"] = { spells = { "Slam" } },
    ["bloodsurge!"] = { spells = { "Slam" } },
    ["slam!"] = { spells = { "Slam" } },
    ["taste for blood"] = { spells = { "Overpower" } },
    ["revenge!"] = { spells = { "Revenge" } },
    ["revenge"] = { spells = { "Revenge" } },
    ["sword and board"] = { spells = { "Shield Slam" } },
    ["sword and board!"] = { spells = { "Shield Slam" } },
    ["victorious"] = { spells = { "Victory Rush" } },
    ["victory rush"] = { spells = { "Victory Rush" } },

    -- HUNTER
    ["lock and load"] = { spells = { "Explosive Shot", "Arcane Shot" } },
    ["improved steady shot"] = { spells = { "Chimera Shot", "Aimed Shot", "Arcane Shot" } },
    ["rapid killing"] = { spells = { "Aimed Shot", "Arcane Shot", "Steady Shot" } },
    ["ready set aim..."] = { spells = { "Aimed Shot", "Chimera Shot", "Arcane Shot" } },

    -- SHAMAN
    ["maelstrom weapon"] = { minStacks = 5, spells = { "Lightning Bolt", "Chain Lightning", "Lesser Healing Wave", "Healing Wave", "Chain Heal", "Hex" } },
    ["tidal waves"] = { spells = { "Healing Wave", "Lesser Healing Wave" } },
    ["elemental focus"] = { autoAlert = false, classSpells = { SHAMAN = { "Lightning Bolt", "Chain Lightning", "Lava Burst", "Healing Wave", "Lesser Healing Wave", "Chain Heal" } } },
    ["clearcasting elemental"] = { autoAlert = false, classSpells = { SHAMAN = { "Lightning Bolt", "Chain Lightning", "Lava Burst" } } },
    ["ancestral awakening"] = { ignore = true },

    -- DRUID
    ["eclipse (lunar)"] = { spells = { "Starfire" } },
    ["eclipse lunar"] = { spells = { "Starfire" } },
    ["lunar eclipse"] = { spells = { "Starfire" } },
    ["eclipse (solar)"] = { spells = { "Wrath" } },
    ["eclipse solar"] = { spells = { "Wrath" } },
    ["solar eclipse"] = { spells = { "Wrath" } },
    ["eclipse"] = { spells = { "Starfire", "Wrath" } },
    ["omen of clarity"] = { autoAlert = false, classSpells = { DRUID = { "Wrath", "Starfire", "Regrowth", "Healing Touch", "Nourish", "Rejuvenation" } } },
    ["predatory strikes"] = { spells = { "Healing Touch", "Cyclone", "Entangling Roots", "Hibernate", "Rebirth" } },
    ["nature's grace"] = { autoAlert = false, classSpells = { DRUID = { "Starfire", "Wrath", "Healing Touch", "Regrowth", "Nourish" } } },
    ["natures grace"] = { autoAlert = false, classSpells = { DRUID = { "Starfire", "Wrath", "Healing Touch", "Regrowth", "Nourish" } } },

    -- PRIEST
    ["surge of light"] = { spells = { "Flash Heal", "Smite" } },
    ["serendipity"] = { minStacks = 3, spells = { "Prayer of Healing", "Greater Heal" } },
    ["borrowed time"] = { autoAlert = false, classSpells = { PRIEST = { "Flash Heal", "Greater Heal", "Prayer of Healing", "Penance" } } },
    ["holy concentration"] = { ignore = true },
    ["improved spirit tap"] = { ignore = true },

    -- WARLOCK
    ["nightfall"] = { spells = { "Shadow Bolt" } },
    ["shadow trance"] = { spells = { "Shadow Bolt" } },
    ["backlash"] = { spells = { "Incinerate", "Shadow Bolt" } },
    ["backdraft"] = { spells = { "Incinerate", "Chaos Bolt", "Soul Fire" } },
    ["pyroclasm"] = { spells = { "Incinerate", "Soul Fire", "Shadow Bolt" } },
    ["molten core"] = { spells = { "Incinerate", "Soul Fire" } },
    ["decimation"] = { spells = { "Soul Fire" } },
    ["eradication"] = { autoAlert = false, classSpells = { WARLOCK = { "Shadow Bolt", "Incinerate", "Drain Soul", "Haunt" } } },

    -- GENERIC / SHARED BUFF NAMES
    ["clearcasting"] = { spells = { "Regrowth", "Healing Touch", "Nourish", "Starfire", "Wrath", "Arcane Blast", "Arcane Missiles", "Arcane Barrage", "Fireball", "Frostbolt", "Lightning Bolt", "Chain Lightning", "Lava Burst", "Healing Wave", "Lesser Healing Wave", "Chain Heal" } },
}

local function NormalizeProcName(name)
    name = string.lower(tostring(name or ""))
    name = name:gsub("^the%s+", "")
    name = name:gsub("[%c%p]", "")
    name = name:gsub("%s+", " ")
    name = name:gsub("^%s+", ""):gsub("%s+$", "")
    return name
end

local function ResolveProcFilterName(name)
    local text = Trim(name or "")
    local lower = string.lower(text)
    if lower == "execute" or lower == "execute range" or lower == "execute-range" or lower == "target execute" or lower == "target <= 20" or lower == "target <= 20% hp" then
        return "Target <= 20% HP"
    end
    if lower == "how" or lower == "hammer" or lower == "hammer of wrath" then
        return "Target <= 20% HP"
    end
    return text
end

local function IsProcDisabled(name)
    if not DB or type(DB.disabledProcs) ~= "table" or not name then return false end
    return DB.disabledProcs[NormalizeProcName(ResolveProcFilterName(name))] == true
end

local function SetProcDisabled(name, disabled)
    if not DB then return end
    name = ResolveProcFilterName(name)
    if not name or name == "" then
        Print("Usage: /cw procignore <proc name> or /cw procallow <proc name>")
        Print("Example: /cw procignore Art of War")
        Print("Example: /cw procignore execute")
        return
    end
    DB.disabledProcs = DB.disabledProcs or {}
    local key = NormalizeProcName(name)
    if disabled then
        DB.disabledProcs[key] = true
        Print("proc ignored: " .. tostring(name))
    else
        DB.disabledProcs[key] = nil
        Print("proc allowed: " .. tostring(name))
    end
    consumedProcAuras = {}
    lastAutoProcAlert = {}
    alertCooldowns = {}
    pendingProcAlert = nil
    if ClearHotbarProcHighlights then ClearHotbarProcHighlights() end
    if Refresh then Refresh() end
    if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
end

local function ToggleProcDisabled(name)
    name = ResolveProcFilterName(name)
    if not name or name == "" then
        Print("Usage: /cw proctoggle <proc name>")
        return
    end
    DB.disabledProcs = DB.disabledProcs or {}
    local key = NormalizeProcName(name)
    SetProcDisabled(name, not DB.disabledProcs[key])
end

local function ListDisabledProcs()
    if not DB or type(DB.disabledProcs) ~= "table" then
        Print("ignored procs: none")
        return
    end


local function PrintProcAudit()
    local supported = 0
    local ignored = 0
    local autoMuted = 0
    for key, entry in pairs(SMART_PROC_MAP or {}) do
        supported = supported + 1
        if type(entry) == "table" and entry.ignore == true then
            ignored = ignored + 1
        elseif type(entry) == "table" and entry.autoAlert == false then
            autoMuted = autoMuted + 1
        end
    end
    Print("proc audit: " .. tostring(supported) .. " mapped proc names")
    Print("proc audit: " .. tostring(autoMuted) .. " broad buffs have auto-pop disabled")
    Print("proc audit: " .. tostring(ignored) .. " passive/non-action buffs ignored by default")
    Print("proc audit: use /cw procignore <name> to disable a noisy proc for yourself")
end

    local any = false
    for key, disabled in pairs(DB.disabledProcs) do
        if disabled then
            if not any then Print("ignored procs:") end
            any = true
            Print("  " .. tostring(key))
        end
    end
    if not any then Print("ignored procs: none") end
end


local function AddProcTargetsForAura(targets, auraName, auraCount)
    if not auraName then return end
    local raw = string.lower(tostring(auraName))
    local norm = NormalizeProcName(auraName)
    if IsProcDisabled and IsProcDisabled(auraName) then
        if DB and DB.procDebug then Print("PROC IGNORED: " .. tostring(auraName)) end
        return
    end
    local entry = SMART_PROC_MAP[raw] or SMART_PROC_MAP[norm] or SMART_PROC_MAP["the " .. norm]

    -- Extra safety for Wrath clients/private servers that expose slightly different proc names.
    if not entry and (raw:find("art of war") or norm:find("art of war")) then
        entry = { spells = { "Exorcism", "Flash of Light" } }
    elseif not entry and (raw:find("shadow trance") or norm:find("shadow trance")) then
        entry = { spells = { "Shadow Bolt" } }
    elseif not entry and (raw:find("freezing fog") or norm:find("freezing fog")) then
        entry = { spells = { "Howling Blast" } }
    elseif not entry and (raw:find("bloodsurge") or norm:find("bloodsurge") or raw:find("slam")) then
        entry = { spells = { "Slam" } }
    elseif not entry and (raw:find("sword and board") or norm:find("sword and board")) then
        entry = { spells = { "Shield Slam" } }
    elseif not entry and (raw:find("missile barrage") or norm:find("missile barrage")) then
        entry = { spells = { "Arcane Missiles" } }
    elseif not entry and (raw:find("lock and load") or norm:find("lock and load")) then
        entry = { spells = { "Explosive Shot", "Arcane Shot" } }
    elseif not entry and (raw:find("decimation") or norm:find("decimation")) then
        entry = { spells = { "Soul Fire" } }
    elseif not entry and (raw:find("molten core") or norm:find("molten core")) then
        entry = { spells = { "Incinerate", "Soul Fire" } }
    elseif not entry and (raw:find("surge of light") or norm:find("surge of light")) then
        entry = { spells = { "Flash Heal", "Smite" } }
    elseif not entry and (raw:find("omen of clarity") or norm:find("omen of clarity")) then
        entry = { autoAlert = false, classSpells = { DRUID = { "Wrath", "Starfire", "Regrowth", "Healing Touch", "Nourish", "Rejuvenation" } } }
    elseif not entry and (raw:find("clearcasting") or norm:find("clearcasting")) then
        entry = SMART_PROC_MAP["clearcasting"]
    end

    if not entry then return end
    if type(entry) == "table" and entry.ignore == true then
        if DB and DB.procDebug then Print("PROC IGNORED BY DEFAULT: " .. tostring(auraName)) end
        return
    end

    local minStacks = entry.minStacks or 0
    local stacks = tonumber(auraCount or 0) or 0
    if minStacks > 0 and stacks < minStacks then
        return
    end

    local list = entry.spells or entry
    if not list then return end

    for idx, spellName in ipairs(list) do
        targets[string.lower(tostring(spellName))] = auraName
        table.insert(currentProcCandidates, { spell = spellName, aura = auraName, primary = (idx == 1) })
        local resolved = GetSpellInfo(spellName)
        if resolved then
            targets[string.lower(tostring(resolved))] = auraName
            if resolved ~= spellName then
                table.insert(currentProcCandidates, { spell = resolved, aura = auraName, primary = (idx == 1) })
            end
        end
    end

    if DB and DB.procDebug then
        Print("PROC ON: " .. tostring(auraName) .. ((minStacks > 0) and (" " .. tostring(stacks) .. "/" .. tostring(minStacks)) or ""))
    end
end

local function BuildActiveProcTargets()
    local targets = {}
    currentProcCandidates = {}
    if not DB or not DB.smartProc then return targets end

    local activeAuras = {}
    for i = 1, 40 do
        local name, count = nil, nil
        if UnitBuff then
            local n, _, _, c = UnitBuff("player", i)
            name, count = n, c
        end
        if not name and UnitAura then
            local n, _, _, c = UnitAura("player", i, "HELPFUL")
            name, count = n, c
        end
        if not name and UnitAura then
            local n, _, _, c = UnitAura("player", i)
            name, count = n, c
        end
        if name then
            local norm = NormalizeProcName(name)
            activeAuras[norm] = true
            -- If a proc was already consumed, do not keep showing USE just because
            -- a Wrath/private-server aura update is delayed or sticky. The alert is
            -- allowed again only after that aura disappears and then appears again.
            if not consumedProcAuras[norm] then
                AddProcTargetsForAura(targets, name, count)
            end
        end
    end

    for norm in pairs(consumedProcAuras) do
        if not activeAuras[norm] then
            consumedProcAuras[norm] = nil
        end
    end

    -- Execute-range smart procs. These are not player auras, so treat target HP as a pseudo-proc.
    -- Beta43: restrict by player class instead of scanning every execute spell. This keeps
    -- Paladins from seeing Kill Shot, while also making Hammer of Wrath reliable again.
    if IsTargetInExecuteRange() and not (IsProcDisabled and IsProcDisabled("Target <= 20% HP")) then
        local added = {}
        local classFile = GetPlayerClassFile()
        local executeSpells = EXECUTE_SPELLS_BY_CLASS[classFile] or {}
        for _, executeName in ipairs(executeSpells) do
            local resolved, icon = ResolveExecuteSpellInfo(executeName)
            if resolved then
                targets[string.lower(tostring(executeName))] = "Target <= 20% HP"
                targets[string.lower(tostring(resolved))] = "Target <= 20% HP"
                table.insert(currentProcCandidates, { spell = resolved, aura = "Target <= 20% HP", primary = true, icon = icon })
                added[resolved] = true
            end
        end
        if DB and DB.procDebug then
            local line = ""
            for n in pairs(added) do line = line .. (line ~= "" and ", " or "") .. n end
            Print("PROC ON: Target <= 20% HP" .. (line ~= "" and (" -> " .. line) or ""))
        end
    end

    return targets
end

local function SuppressConsumedProcForSpell(spellName)
    if not spellName or not DB or not DB.smartProc then return end
    local activeProcTargets = BuildActiveProcTargets()
    local procAura = GetProcAuraForSpell(spellName, activeProcTargets)
    if procAura then
        consumedProcAuras[NormalizeProcName(procAura)] = true
        if DB and DB.procDebug then Print("PROC USED: " .. tostring(procAura) .. " -> " .. tostring(spellName)) end
        if Refresh then Refresh() end
    end
end

GetProcAuraForSpell = function(spellName, activeProcTargets)
    if not spellName or not activeProcTargets then return nil end
    return activeProcTargets[string.lower(tostring(spellName))]
end



local function GetAlertTypeForAura(auraName)
    local a = string.lower(tostring(auraName or ""))
    if a:find("target <= 20") or a:find("execute range") then
        return "EXECUTE"
    end
    if a:find("infusion of light") or a:find("maelstrom") or a:find("serendipity") or a:find("tidal waves") or a:find("clearcasting") or a:find("omen of clarity") or a:find("borrowed time") or a:find("holy concentration") or a:find("elemental focus") or a:find("nature") or a:find("presence of mind") or a:find("lights grace") or a:find("light's grace") then
        return "BUFF"
    end
    return "PROC"
end

local function GetAlertLabelForType(alertType)
    if alertType == "EXECUTE" then return "EXECUTE" end
    if alertType == "BUFF" then return "BUFF" end
    return "PROC"
end

local function GetAlertColor(alertType)
    if alertType == "EXECUTE" then
        return 1.0, 0.12, 0.08
    elseif alertType == "BUFF" then
        return 0.25, 0.65, 1.0
    end
    return 0.15, 1.0, 0.25
end

local function ColorProcTexture(texture, alertType)
    if not texture or not texture.SetVertexColor then return end
    local r, g, b = GetAlertColor(alertType)
    texture:SetVertexColor(r, g, b, 1)
end

local function ColorProcFont(fontString, alertType)
    if not fontString or not fontString.SetTextColor then return end
    local r, g, b = GetAlertColor(alertType)
    fontString:SetTextColor(r, g, b, 1)
end

local function GetProcRecommendationVerb(alertType)
    if not (DB and DB.procRecommendationText) then
        return GetAlertLabelForType(alertType)
    end
    if alertType == "EXECUTE" then return "EXECUTE" end
    if alertType == "BUFF" then return "CAST" end
    return "USE"
end

local function CleanBindingText(key)
    if not key or key == "" then return nil end
    local text = tostring(key)
    if GetBindingText then text = GetBindingText(text, "KEY_") or text end
    text = string.gsub(text, "CTRL%-", "C-")
    text = string.gsub(text, "SHIFT%-", "S-")
    text = string.gsub(text, "ALT%-", "A-")
    text = string.gsub(text, "MOUSEWHEELUP", "MWU")
    text = string.gsub(text, "MOUSEWHEELDOWN", "MWD")
    return text
end

local function GetActionSlotBinding(slot)
    slot = tonumber(slot or 0) or 0
    if not GetBindingKey or slot <= 0 then return nil end
    local command
    if slot >= 1 and slot <= 12 then command = "ACTIONBUTTON" .. tostring(slot)
    elseif slot >= 61 and slot <= 72 then command = "MULTIACTIONBAR1BUTTON" .. tostring(slot - 60)
    elseif slot >= 49 and slot <= 60 then command = "MULTIACTIONBAR2BUTTON" .. tostring(slot - 48)
    elseif slot >= 25 and slot <= 36 then command = "MULTIACTIONBAR3BUTTON" .. tostring(slot - 24)
    elseif slot >= 37 and slot <= 48 then command = "MULTIACTIONBAR4BUTTON" .. tostring(slot - 36) end
    if command then return CleanBindingText(GetBindingKey(command)) end
    return nil
end

local function GetVisibleButtonHotkey(button)
    if not button then return nil end
    local name = button.GetName and button:GetName()
    local candidates = {
        button.HotKey, button.hotkey, button.Hotkey, button.keybind, button.Keybind, button.bindText,
        name and _G[name .. "HotKey"],
        name and _G[name .. "Hotkey"],
        name and _G[name .. "Keybind"],
    }
    for _, fs in ipairs(candidates) do
        if fs and fs.GetText then
            local text = fs:GetText()
            if text and text ~= "" and text ~= RANGE_INDICATOR and text ~= "●" then
                text = tostring(text)
                if text ~= "???" and text ~= "-" then
                    return CleanBindingText(text)
                end
            end
        elseif type(fs) == "string" and fs ~= "" then
            return CleanBindingText(fs)
        end
    end
    return nil
end

local function GetButtonBindingText(button, fallbackSlot)
    if not (DB and DB.keybindOverlay) then return nil end

    -- First trust the hotkey text already drawn on the action button. ElvUI/Bartender/Dominos
    -- often resolve private-server bindings here even when GetBindingKey() gives us nothing.
    local visible = GetVisibleButtonHotkey(button)
    if visible then return visible end

    if GetBindingKey and button and button.GetName then
        local name = button:GetName()
        if name then
            local key = GetBindingKey("CLICK " .. name .. ":LeftButton")
            if key then return CleanBindingText(key) end
        end
    end
    return GetActionSlotBinding(fallbackSlot)
end

local hotbarButtons = {
    -- Blizzard default bars
    { name = "ActionButton", base = 0 },
    { name = "BonusActionButton", base = 0 },
    { name = "MultiBarBottomLeftButton", base = 60 },
    { name = "MultiBarBottomRightButton", base = 48 },
    { name = "MultiBarRightButton", base = 24 },
    { name = "MultiBarLeftButton", base = 36 },
    -- ElvUI 3.3.5 button names. These usually expose their action via .action or secure attributes.
    { name = "ElvUI_Bar1Button", base = 0 },
    { name = "ElvUI_Bar2Button", base = 0 },
    { name = "ElvUI_Bar3Button", base = 0 },
    { name = "ElvUI_Bar4Button", base = 0 },
    { name = "ElvUI_Bar5Button", base = 0 },
    { name = "ElvUI_Bar6Button", base = 0 },
    { name = "ElvUI_Bar7Button", base = 0 },
    { name = "ElvUI_Bar8Button", base = 0 },
    { name = "ElvUI_Bar9Button", base = 0 },
    { name = "ElvUI_Bar10Button", base = 0 },
}


local hotbarTouchedButtons = {}
local IsPossibleActionButton

local function MarkHotbarCacheDirty()
    hotbarCacheDirty = true
end

local function ResetSpecSensitiveAlertState()
    -- 1.2.2: clear old overlays BEFORE wiping the touched-button table.
    -- ElvUI/spec swaps can leave old frames alive long enough for stale USE/EXECUTE
    -- labels to remain visible if we forget the frame refs first.
    if ClearHotbarProcHighlights then ClearHotbarProcHighlights() end
    MarkHotbarCacheDirty()
    lastHotbarSignature = ""
    hotbarButtonCache = nil
    hotbarTouchedButtons = {}
    lastAutoProcAlert = {}
    alertCooldowns = {}
    pendingProcAlert = nil
    if procAlertFrame then procAlertFrame:Hide() end
end

local function RebuildHotbarButtonCache()
    hotbarButtonCache = {}
    local seen = {}

    local function addButton(button, fallbackSlot)
        if not button or seen[button] then return end
        if button.IsShown and not button:IsShown() then return end
        if button.IsVisible and not button:IsVisible() then return end
        if button.GetWidth and button.GetHeight then
            local w = button:GetWidth() or 0
            local h = button:GetHeight() or 0
            if w < 18 or h < 18 or w > 96 or h > 96 then return end
        end
        seen[button] = true
        table.insert(hotbarButtonCache, { button = button, slot = fallbackSlot })
    end

    for _, group in ipairs(hotbarButtons) do
        for i = 1, 12 do
            addButton(_G[group.name .. tostring(i)], group.base + i)
        end
    end

    -- 1.2.2: no broad EnumerateFrames scan.
    -- Private/ElvUI clients can expose editor/test/clone frames that look like action buttons.
    -- Known bar names plus visible-frame filtering is more reliable and prevents stale duplicate USE/EXECUTE labels.
    hotbarCacheDirty = false
    lastHotbarCacheBuild = GetTime and GetTime() or 0
end

local function ClearHotbarProcHighlights()
    for button in pairs(hotbarTouchedButtons) do
        if button and button.cwHotbarGlow then button.cwHotbarGlow:Hide() end
        if button and button.cwHotbarText then button.cwHotbarText:Hide(); SafeSetScale(button.cwHotbarText, 1) end
    end
end

local function SpellNameFromMacroBody(body)
    if not body then return nil end
    for line in string.gmatch(tostring(body), "[^\n]+") do
        line = Trim(line or "")
        -- Strip comments and common macro prefixes. We only need the first cast/use target.
        if line and line ~= "" and string.sub(line, 1, 1) ~= "#" then
            local spell = line:match("^/cast%s+(.+)$") or line:match("^/use%s+(.+)$") or line:match("^/castsequence%s+(.+)$")
            if spell then
                -- Remove conditionals like [@mouseover,help] and take the first spell before ; or ,
                spell = spell:gsub("%b[]", "")
                spell = spell:match("^([^;,]+)") or spell
                spell = Trim(spell:gsub("!", ""))
                if spell ~= "" then
                    local name = GetSpellInfo(spell)
                    if name then return name end
                    return spell
                end
            end
        end
    end
    return nil
end

local function GetActionButtonSpellName(button, fallbackSlot)
    if not button then return nil end

    -- Secure action buttons used by ElvUI/Bartender-style bars can store spell directly.
    if button.GetAttribute then
        local atype = button:GetAttribute("type") or button:GetAttribute("type1")
        local spell = button:GetAttribute("spell") or button:GetAttribute("spell1")
        if (atype == "spell" or spell) and spell then
            local name = GetSpellInfo(spell)
            if name then return name end
            return tostring(spell)
        end
        local macrotext = button:GetAttribute("macrotext") or button:GetAttribute("macrotext1")
        local macroSpell = SpellNameFromMacroBody(macrotext)
        if macroSpell then return macroSpell end
    end

    local slot = button.action or button._state_action or (button.GetAttribute and button:GetAttribute("action")) or fallbackSlot
    if slot and GetActionInfo then
        slot = tonumber(slot) or slot
        local actionType, id = GetActionInfo(slot)
        if actionType == "spell" and id then
            local name = GetSpellInfo(id)
            if name then return name end
        elseif actionType == "macro" and id then
            if GetMacroSpell then
                local spell = GetMacroSpell(id)
                if spell then return spell end
            end
            if GetMacroInfo then
                local _, _, body = GetMacroInfo(id)
                local macroSpell = SpellNameFromMacroBody(body)
                if macroSpell then return macroSpell end
            end
        elseif actionType == "item" then
            return nil
        end
    end
    return nil
end

local function EnsureHotbarGlow(button)
    if not button or button.cwHotbarGlow then return end
    local g = button:CreateTexture(nil, "OVERLAY")
    g:SetPoint("CENTER", button, "CENTER", 0, 0)
    g:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    g:SetBlendMode("ADD")
    g:SetWidth(72)
    g:SetHeight(72)
    g:SetAlpha(1)
    g:Hide()
    button.cwHotbarGlow = g
    local t = button:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    t:SetPoint("TOP", button, "TOP", 0, 8)
    if t.SetFont then t:SetFont("Fonts\\FRIZQT__.TTF", 14, "OUTLINE") end
    t:SetTextColor(1, 0.85, 0.1, 1)
    t:SetText("")
    t:Hide()
    button.cwHotbarText = t
end

local function TextureName(tex)
    if not tex then return nil end
    if type(tex) == "string" then return string.lower(tex) end
    if tex.GetTexture then
        local t = tex:GetTexture()
        if t then return string.lower(tostring(t)) end
    end
    return nil
end

local function GetButtonIconTexture(button)
    if not button then return nil end
    local name = button.GetName and button:GetName()
    local candidates = {
        button.icon, button.Icon, button.texture, button.Texture, button._icon,
        name and _G[name .. "Icon"],
        name and _G[name .. "IconTexture"],
        name and _G[name .. "NormalTexture"],
    }
    for _, tex in ipairs(candidates) do
        local t = TextureName(tex)
        if t then return t end
    end
    return nil
end

local function BuildActiveSpellIconTargets(activeProcTargets)
    local icons = {}
    if not activeProcTargets then return icons end
    for spellKey, aura in pairs(activeProcTargets) do
        local name, _, icon = GetSpellInfo(spellKey)
        if not icon and type(spellKey) == "string" then
            name, _, icon = GetSpellInfo(tostring(spellKey))
        end
        if icon then icons[string.lower(tostring(icon))] = aura end
    end
    -- Execute and some macro-only cases may have been added through currentProcCandidates
    -- with a fallback icon rather than a clean GetSpellInfo result. Include those too.
    for _, candidate in ipairs(currentProcCandidates or {}) do
        if candidate and candidate.icon and candidate.aura then
            icons[string.lower(tostring(candidate.icon))] = candidate.aura
        end
    end
    return icons
end

local function ResolveHotbarProcAura(button, fallbackSlot, activeProcTargets, activeSpellIcons)
    if not activeProcTargets then return nil, nil, nil end
    local spellName = GetActionButtonSpellName(button, fallbackSlot)
    if spellName then
        local lowerSpell = string.lower(tostring(spellName))
        local aura = activeProcTargets[lowerSpell]
        if aura then return aura, "spell", "spell:" .. lowerSpell end
        local resolved = GetSpellInfo(spellName)
        if resolved then
            local lowerResolved = string.lower(tostring(resolved))
            aura = activeProcTargets[lowerResolved]
            if aura then return aura, "spell", "spell:" .. lowerResolved end
        end
    end

    -- Icon fallback is still needed for some ElvUI/macro buttons on Wrath,
    -- but UpdateHotbarProcHighlights dedupes by icon key so clone buttons don't all light up.
    local icon = GetButtonIconTexture(button)
    if icon and activeSpellIcons then
        local aura = activeSpellIcons[icon]
        if aura then return aura, "icon", "icon:" .. tostring(icon) end
    end
    return nil, nil, nil
end

local function ScoreHotbarButton(button, slot, matchMode)
    local score = 0
    if matchMode == "spell" then score = score + 1000 end
    if button and button.IsVisible and button:IsVisible() then score = score + 100 end
    if button and button.IsShown and button:IsShown() then score = score + 50 end
    if GetButtonBindingText(button, slot) then score = score + 25 end
    local name = button and button.GetName and button:GetName() or ""
    if name and name:find("ElvUI_Bar1Button") then score = score + 30 end
    if name and name:find("ActionButton") then score = score + 20 end
    if button and button.GetFrameLevel then score = score + math.min(button:GetFrameLevel() or 0, 25) end
    return score
end

local function GetKeybindForSpell(spellName)
    if not (DB and DB.keybindOverlay and spellName) then return nil end
    if hotbarCacheDirty or not hotbarButtonCache then RebuildHotbarButtonCache() end

    local wanted = string.lower(tostring(spellName))
    local resolvedWanted, _, wantedIcon = GetSpellInfo(spellName)
    local wantedResolved = resolvedWanted and string.lower(tostring(resolvedWanted)) or wanted
    local wantedIconLower = wantedIcon and string.lower(tostring(wantedIcon)) or nil

    for _, entry in ipairs(hotbarButtonCache or {}) do
        local found = GetActionButtonSpellName(entry.button, entry.slot)
        if found then
            local lower = string.lower(tostring(found))
            if lower == wanted or lower == wantedResolved then return GetButtonBindingText(entry.button, entry.slot) end
            local resolved = GetSpellInfo(found)
            if resolved and string.lower(tostring(resolved)) == wantedResolved then return GetButtonBindingText(entry.button, entry.slot) end
        end
    end

    -- Last-resort matching for bars/macros that expose neither action slot nor macro spell.
    -- If the visible action-button icon matches the tracked spell icon, use that button's shown bind.
    if wantedIconLower then
        for _, entry in ipairs(hotbarButtonCache or {}) do
            local icon = GetButtonIconTexture(entry.button)
            if icon and icon == wantedIconLower then
                local bind = GetButtonBindingText(entry.button, entry.slot)
                if bind then return bind end
            end
        end
    end
    return nil
end

IsPossibleActionButton = function(frame)
    if not frame or not frame.GetName or not frame.GetWidth or not frame.GetHeight then return false end
    local w, h = frame:GetWidth() or 0, frame:GetHeight() or 0
    if w < 18 or h < 18 or w > 96 or h > 96 then return false end
    local name = frame:GetName() or ""
    if name:find("CoolinatorWrath") then return false end
    if frame.action or frame._state_action then return true end
    if frame.GetAttribute then
        if frame:GetAttribute("action") or frame:GetAttribute("type") or frame:GetAttribute("type1") or frame:GetAttribute("spell") or frame:GetAttribute("spell1") or frame:GetAttribute("macrotext") or frame:GetAttribute("macrotext1") then
            return true
        end
    end
    -- Some replacement bars hide the useful info but still have obvious action button names.
    if name:find("ActionButton") or name:find("MultiBar") or name:find("ElvUI") or name:find("Elvui") or name:find("Bartender") or name:find("Dominos") or name:find("BT4Button") then
        return true
    end
    return false
end

local function ApplyHotbarState(button, procAura, now, fallbackSlot)
    if button then hotbarTouchedButtons[button] = true end
    EnsureHotbarGlow(button)
    if procAura then
        local size = (button:GetWidth() or 36)
        local alertType = GetAlertTypeForAura(procAura)
        local pulse = DB.procPulse and ((math.sin(now * 14) + 1) * 0.30) or 0
        button.cwHotbarGlow:SetTexture((DB.procGlowStyle == 3) and "Interface\\SpellActivationOverlay\\IconAlert" or "Interface\\Buttons\\UI-ActionButton-Border")
        ColorProcTexture(button.cwHotbarGlow, alertType)
        button.cwHotbarGlow:SetWidth(size * (2.45 + pulse))
        button.cwHotbarGlow:SetHeight(size * (2.45 + pulse))
        button.cwHotbarGlow:SetAlpha(0.88 + (math.sin(now * 18) + 1) * 0.10)
        button.cwHotbarGlow:Show()
        local keyText = GetButtonBindingText(button, fallbackSlot or button.action or button._state_action or (button.GetAttribute and button:GetAttribute("action")))
        button.cwHotbarText:SetText(GetProcRecommendationVerb(alertType) .. (keyText and (" [" .. keyText .. "]") or ""))
        ColorProcFont(button.cwHotbarText, alertType)
        button.cwHotbarText:Show()
        if DB.procPulse then SafeSetScale(button.cwHotbarText, 1 + (math.sin(now * 16) + 1) * 0.13) else SafeSetScale(button.cwHotbarText, 1) end
    else
        if button.cwHotbarGlow then button.cwHotbarGlow:Hide() end
        if button.cwHotbarText then button.cwHotbarText:Hide(); SafeSetScale(button.cwHotbarText, 1) end
    end
end

UpdateHotbarProcHighlights = function(activeProcTargets)
    if SuppressAlertsForMap and SuppressAlertsForMap() then
        ClearHotbarProcHighlights()
        return
    end

    -- Always clear every button Coolinator has ever touched first.
    ClearHotbarProcHighlights()

    local active = DB and DB.smartProc and DB.hotbarGlow and activeProcTargets
    if not active then return end

    local now = GetTime()
    if hotbarCacheDirty or not hotbarButtonCache or ((now - (lastHotbarCacheBuild or 0)) > 5.0) then
        RebuildHotbarButtonCache()
    end

    local activeSpellIcons = BuildActiveSpellIconTargets(activeProcTargets)
    local bestByKey = {}
    local order = {}

    for _, entry in ipairs(hotbarButtonCache or {}) do
        local button = entry.button
        if button then
            local procAura, matchMode, matchKey = ResolveHotbarProcAura(button, entry.slot, activeProcTargets, activeSpellIcons)
            if procAura and matchKey then
                local score = ScoreHotbarButton(button, entry.slot, matchMode)
                if not bestByKey[matchKey] then
                    table.insert(order, matchKey)
                    bestByKey[matchKey] = { button = button, aura = procAura, slot = entry.slot, score = score }
                elseif score > (bestByKey[matchKey].score or 0) then
                    bestByKey[matchKey] = { button = button, aura = procAura, slot = entry.slot, score = score }
                end
            end
        end
    end

    for _, key in ipairs(order) do
        local best = bestByKey[key]
        if best and best.button and best.aura then
            ApplyHotbarState(best.button, best.aura, now, best.slot)
        end
    end
end
local function ApplyProcAlertStyle(frame)
    if not frame then return end
    frame:ClearAllPoints()
    if DB and DB.procPopout then
        frame:SetWidth(360); frame:SetHeight(160)
        frame:SetPoint("CENTER", UIParent, "CENTER", 0, 120)
        frame.icon:SetWidth(96); frame.icon:SetHeight(96)
        frame.icon:ClearAllPoints(); frame.icon:SetPoint("LEFT", frame, "LEFT", 10, 0)
        frame.glow:SetWidth(190); frame.glow:SetHeight(190)
        frame.title:ClearAllPoints(); frame.title:SetPoint("TOPLEFT", frame.icon, "TOPRIGHT", 14, -18)
        if frame.title.SetFont then frame.title:SetFont("Fonts\\FRIZQT__.TTF", 28, "OUTLINE") end
        frame.spell:ClearAllPoints(); frame.spell:SetPoint("TOPLEFT", frame.title, "BOTTOMLEFT", 0, -4); frame.spell:SetWidth(230)
        if frame.spell.SetFont then frame.spell:SetFont("Fonts\\FRIZQT__.TTF", 24, "OUTLINE") end
    else
        frame:SetWidth(190); frame:SetHeight(82)
        frame:SetPoint("BOTTOM", CW, "TOP", 0, 18)
        frame.icon:SetWidth(48); frame.icon:SetHeight(48)
        frame.icon:ClearAllPoints(); frame.icon:SetPoint("LEFT", frame, "LEFT", 4, 0)
        frame.glow:SetWidth(92); frame.glow:SetHeight(92)
        frame.title:ClearAllPoints(); frame.title:SetPoint("TOPLEFT", frame.icon, "TOPRIGHT", 8, -8)
        if frame.title.SetFont then frame.title:SetFont("Fonts\\FRIZQT__.TTF", 18, "OUTLINE") end
        frame.spell:ClearAllPoints(); frame.spell:SetPoint("TOPLEFT", frame.title, "BOTTOMLEFT", 0, -2); frame.spell:SetWidth(125)
        if frame.spell.SetFont then frame.spell:SetFont("Fonts\\FRIZQT__.TTF", 16, "OUTLINE") end
    end
end

local procAlertFrame
local function EnsureProcAlertFrame()
    if procAlertFrame then return procAlertFrame end

    local f = CreateFrame("Frame", "CoolinatorWrathProcAlert", UIParent)
    f:SetWidth(190)
    f:SetHeight(82)
    f:SetFrameStrata("HIGH")
    f:SetFrameLevel(900)
    f:EnableMouse(false)

    f.icon = f:CreateTexture(nil, "ARTWORK")
    f.icon:SetWidth(48)
    f.icon:SetHeight(48)
    f.icon:SetPoint("LEFT", f, "LEFT", 4, 0)
    f.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")

    f.glow = f:CreateTexture(nil, "OVERLAY")
    f.glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    f.glow:SetBlendMode("ADD")
    f.glow:SetPoint("CENTER", f.icon, "CENTER", 0, 0)
    f.glow:SetWidth(92)
    f.glow:SetHeight(92)
    f.glow:SetAlpha(1)

    f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    f.title:SetPoint("TOPLEFT", f.icon, "TOPRIGHT", 8, -8)
    f.title:SetText("PROC")
    f.title:SetTextColor(1, 0.82, 0.15, 1)
    if f.title.SetFont then f.title:SetFont("Fonts\\FRIZQT__.TTF", 18, "OUTLINE") end

    f.spell = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    f.spell:SetPoint("TOPLEFT", f.title, "BOTTOMLEFT", 0, -2)
    f.spell:SetWidth(125)
    f.spell:SetJustifyH("LEFT")
    f.spell:SetTextColor(1, 1, 1, 1)
    if f.spell.SetFont then f.spell:SetFont("Fonts\\FRIZQT__.TTF", 16, "OUTLINE") end

    f:Hide()
    f:SetScript("OnUpdate", function(self)
        local now = GetTime()
        if not self.endTime or self.endTime <= now then
            self.cwAlertKey = nil
            self.cwAlertPriority = nil
            self.cwAlertType = nil
            self:Hide()
            if pendingProcAlert then
                local nextAlert = pendingProcAlert
                pendingProcAlert = nil
                ShowSingleProcAlert(nextAlert)
            end
            return
        end
        local remain = self.endTime - now
        -- Cheaper animation than older builds: fewer size writes and no extra frame creation.
        local amp = (DB and DB.procPopout) and 0.12 or 0.05
        local speed = (DB and DB.procPopout) and 18 or 14
        local scale = 1 + (math.sin(now * speed) + 1) * amp
        SafeSetScale(self, scale)
        self:SetAlpha(math.min(1, remain * ((DB and DB.procPopout) and 1.15 or 1.8)))
        if self.glow then
            self.glow:SetAlpha(0.60 + (math.sin(now * 14) + 1) * 0.18)
        end
    end)

    procAlertFrame = f
    return f
end


local SOUND_PROFILES = {
    Minimal = { PROC = "TELL", BUFF = "TELL", EXECUTE = "TELL", enabled = false },
    Default = { PROC = "RAID", BUFF = "TELL", EXECUTE = "LEVEL", enabled = true },
    Loud = { PROC = "ALARM", BUFF = "RAID", EXECUTE = "LEVEL", enabled = true },
    PvP = { PROC = "ALARM", BUFF = "ALARM", EXECUTE = "LEVEL", enabled = true },
    Streamer = { PROC = "TELL", BUFF = "TELL", EXECUTE = "TELL", enabled = false },
}
local SOUND_PROFILE_ORDER = { "Minimal", "Default", "Loud", "PvP", "Streamer" }

local function ApplySoundProfile(name)
    if not DB then return end
    name = tostring(name or DB.soundProfile or "Default")
    local normalized
    for _, n in ipairs(SOUND_PROFILE_ORDER) do
        if string.lower(n) == string.lower(name) then normalized = n end
    end
    if not normalized then normalized = "Default" end
    local profile = SOUND_PROFILES[normalized] or SOUND_PROFILES.Default
    DB.soundProfile = normalized
    DB.procSoundProcMode = profile.PROC or "RAID"
    DB.procSoundBuffMode = profile.BUFF or "TELL"
    DB.procSoundExecuteMode = profile.EXECUTE or "LEVEL"
    DB.procSoundMode = DB.procSoundProcMode
    if profile.enabled ~= nil then DB.procSound = profile.enabled end
    Print("sound profile: " .. normalized .. (DB.procSound and " (sound on)" or " (mostly visual)"))
end

local function CycleSoundProfile()
    local current = DB and DB.soundProfile or "Default"
    local idx = 0
    for i, n in ipairs(SOUND_PROFILE_ORDER) do if n == current then idx = i end end
    idx = (idx % table.getn(SOUND_PROFILE_ORDER)) + 1
    ApplySoundProfile(SOUND_PROFILE_ORDER[idx])
end

local function GetProcSoundName(alertType)
    local mode
    if alertType == "EXECUTE" then
        mode = DB and (DB.procSoundExecuteMode or DB.procSoundMode) or "LEVEL"
    elseif alertType == "BUFF" then
        mode = DB and (DB.procSoundBuffMode or DB.procSoundMode) or "TELL"
    else
        mode = DB and (DB.procSoundProcMode or DB.procSoundMode) or "RAID"
    end

    if mode == "TELL" then return "TellMessage" end
    if mode == "AUCTION" then return "AuctionWindowOpen" end
    if mode == "LEVEL" then return "LevelUp" end
    if mode == "ALARM" then return "RaidWarning" end
    return "RaidWarning"
end

local function PlayProcSound(alertType)
    if not (DB and DB.procSound and PlaySound) then return end
    PlaySound(GetProcSoundName(alertType))
end

local function CycleProcSoundMode()
    local mode = DB and DB.procSoundMode or "RAID"
    if mode == "RAID" then DB.procSoundMode = "TELL"
    elseif mode == "TELL" then DB.procSoundMode = "AUCTION"
    elseif mode == "AUCTION" then DB.procSoundMode = "LEVEL"
    else DB.procSoundMode = "RAID" end
    DB.procSoundProcMode = DB.procSoundMode
    DB.procSoundBuffMode = DB.procSoundMode
    DB.procSoundExecuteMode = DB.procSoundMode
    DB.soundProfile = "Custom"
    Print("proc sound style: " .. tostring(DB.procSoundMode) .. " (custom)")
end

local function TestProcSound()
    if not DB then return end
    if not DB.procSound then
        DB.procSound = true
        Print("proc sound enabled")
    end
    if PlaySound then
        PlaySound(GetProcSoundName("PROC"))
        Print("test sound: PROC")
    else
        Print("PlaySound API unavailable on this client")
    end
end

local function CycleProcGlowStyle()
    DB.procGlowStyle = ((DB.procGlowStyle or 1) % 3) + 1
    Print("proc glow style: " .. tostring(DB.procGlowStyle))
end

local function SetTimerScaleDelta(delta)
    local v = (DB and DB.timerScale) or 1.0
    v = v + (delta or 0)
    if v < 0.70 then v = 0.70 end
    if v > 1.60 then v = 1.60 end
    DB.timerScale = v
    Print("cooldown number size: " .. tostring(math.floor(v * 100 + 0.5)) .. "%")
end

local function CycleTimerScale()
    local v = DB.timerScale or 1.0
    if v < 0.85 then v = 1.0
    elseif v < 1.0 then v = 1.15
    elseif v < 1.15 then v = 1.30
    elseif v < 1.30 then v = 1.45
    elseif v < 1.45 then v = 1.60
    else v = 0.70 end
    DB.timerScale = v
    Print("cooldown number size: " .. tostring(math.floor(v * 100 + 0.5)) .. "%")
end

local procTestIndex = 0
local function TestProcVisuals()
    procTestMode = true
    testMode = true
    procTestIndex = ((procTestIndex or 0) % 3) + 1
    if Refresh then Refresh() end
    if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    if procTestIndex == 1 then
        Print("alert visual test: PROC")
        if FireProcAlert then FireProcAlert(nil, "Exorcism", "Interface\\Icons\\Spell_Holy_Excorcism_02", "The Art of War") end
    elseif procTestIndex == 2 then
        Print("alert visual test: BUFF")
        if FireProcAlert then FireProcAlert(nil, "Flash of Light", "Interface\\Icons\\Spell_Holy_FlashHeal", "Infusion of Light") end
    else
        Print("alert visual test: EXECUTE")
        if FireProcAlert then FireProcAlert(nil, "Hammer of Wrath", "Interface\\Icons\\Ability_ThunderClap", "Target <= 20% HP") end
    end
end

local function ShallowCopyList(src)
    local dst = {}
    for i,v in ipairs(src or {}) do dst[i] = v end
    return dst
end

local function ShallowCopyMap(src)
    local dst = {}
    for k,v in pairs(src or {}) do dst[k] = v end
    return dst
end

local function DeepCopyPositions(src)
    local dst = {}
    for k,v in pairs(src or {}) do
        if type(v) == "table" then dst[k] = { x = v.x or 0, y = v.y or 0 } end
    end
    return dst
end

local function BuildProfileData()
    return {
        spells = ShallowCopyList(DB.spells),
        items = ShallowCopyList(DB.items),
        auras = ShallowCopyList(DB.auras),
        equipmentSlots = ShallowCopyList(DB.equipmentSlots),
        disabledProcs = ShallowCopyMap(DB.disabledProcs),
        iconPositions = DeepCopyPositions(DB.iconPositions),
        addSlotPosition = { x = (DB.addSlotPosition and DB.addSlotPosition.x) or 0, y = (DB.addSlotPosition and DB.addSlotPosition.y) or 0 },
        iconSize = DB.iconSize or 36,
        spacing = DB.spacing or 4,
        maxColumns = DB.maxColumns or 8,
        freeform = DB.freeform,
        growDirection = DB.growDirection or "RIGHT",
        canvasWidth = DB.canvasWidth or 600,
        canvasHeight = DB.canvasHeight or 400,
        snap = DB.snap or 4,
    }
end

local function ApplyProfileData(data)
    if type(data) ~= "table" then Print("Profile data missing."); return end
    DB.spells = ShallowCopyList(data.spells)
    DB.items = ShallowCopyList(data.items)
    DB.auras = ShallowCopyList(data.auras)
    DB.equipmentSlots = ShallowCopyList(data.equipmentSlots)
    DB.disabledProcs = ShallowCopyMap(data.disabledProcs)
    DB.iconPositions = DeepCopyPositions(data.iconPositions)
    DB.addSlotPosition = { x = (data.addSlotPosition and data.addSlotPosition.x) or 0, y = (data.addSlotPosition and data.addSlotPosition.y) or 0 }
    DB.iconSize = data.iconSize or DB.iconSize or 36
    DB.spacing = data.spacing or DB.spacing or 4
    DB.maxColumns = data.maxColumns or DB.maxColumns or 8
    DB.freeform = data.freeform ~= false
    DB.growDirection = data.growDirection or DB.growDirection or "RIGHT"
    DB.canvasWidth = data.canvasWidth or DB.canvasWidth or 600
    DB.canvasHeight = data.canvasHeight or DB.canvasHeight or 400
    DB.snap = data.snap or DB.snap or 4
    if Refresh then Refresh() end
    if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
end

local function SaveProfile(name)
    name = Trim(name or "")
    if name == "" then name = DB.activeProfile or "Default" end
    DB.profiles = DB.profiles or {}
    DB.profiles[name] = BuildProfileData()
    DB.activeProfile = name
    Print("profile saved: " .. name)
end

local function LoadProfile(name)
    name = Trim(name or "")
    if name == "" then name = DB.activeProfile or "Default" end
    DB.profiles = DB.profiles or {}
    if not DB.profiles[name] then Print("profile not found: " .. name); return end
    DB.activeProfile = name
    ApplyProfileData(DB.profiles[name])
    Print("profile loaded: " .. name)
end

local function DeleteProfile(name)
    name = Trim(name or "")
    if name == "" then Print("Usage: /cw profile delete <name>"); return end
    DB.profiles = DB.profiles or {}
    DB.profiles[name] = nil
    Print("profile deleted: " .. name)
end

local function ListProfiles()
    DB.profiles = DB.profiles or {}
    Print("profiles:")
    local found = false
    for k in pairs(DB.profiles) do
        found = true
        Print("  " .. tostring(k) .. ((DB.activeProfile == k) and " (active)" or ""))
    end
    if not found then Print("  none saved yet") end
end

local function GetSpecProfileName()
    local spec = 1
    if GetActiveTalentGroup then spec = GetActiveTalentGroup() or 1 end
    return "Spec " .. tostring(spec)
end

local function EscapeField(v)
    v = tostring(v or "")
    v = v:gsub("%%", "%%%%"):gsub(";", "%%s"):gsub("|", "%%p"):gsub(",", "%%c"):gsub("=", "%%e")
    return v
end

local function UnescapeField(v)
    v = tostring(v or "")
    v = v:gsub("%%e", "="):gsub("%%c", ","):gsub("%%p", "|"):gsub("%%s", ";"):gsub("%%%%", "%%")
    return v
end

local function JoinEscaped(list)
    local out = {}
    for i,v in ipairs(list or {}) do table.insert(out, EscapeField(v)) end
    return table.concat(out, ",")
end

local function SplitEscaped(s)
    local out = {}
    if not s or s == "" then return out end
    for part in string.gmatch(s, "([^,]+)") do table.insert(out, UnescapeField(part)) end
    return out
end

local function ExportLayout()
    local pos = {}
    for k,v in pairs(DB.iconPositions or {}) do
        if type(v) == "table" then table.insert(pos, EscapeField(k) .. "," .. tostring(math.floor((v.x or 0)+0.5)) .. "," .. tostring(math.floor((v.y or 0)+0.5))) end
    end
    local parts = {
        "CWLAYOUT1",
        "spells=" .. JoinEscaped(DB.spells),
        "items=" .. JoinEscaped(DB.items),
        "auras=" .. JoinEscaped(DB.auras),
        "pos=" .. table.concat(pos, "|"),
        "add=" .. tostring((DB.addSlotPosition and DB.addSlotPosition.x) or 0) .. "," .. tostring((DB.addSlotPosition and DB.addSlotPosition.y) or 0),
        "size=" .. tostring(DB.iconSize or 36),
        "cols=" .. tostring(DB.maxColumns or 8),
    }
    local text = table.concat(parts, ";")
    Print("layout export below. Copy from chat if your client allows it:")
    Print(text)
    return text
end

local function ImportLayout(text)
    text = Trim(text or "")
    if text == "" then Print("Usage: /cw import <layout string>"); return end
    if not string.find(text, "^CWLAYOUT1;") then Print("Import failed: invalid layout string."); return end
    local data = {}
    for part in string.gmatch(text, "([^;]+)") do
        local k,v = part:match("^([^=]+)=(.*)$")
        if k and v then data[k] = v end
    end
    DB.spells = SplitEscaped(data.spells)
    DB.items = SplitEscaped(data.items)
    DB.auras = SplitEscaped(data.auras)
    DB.iconPositions = {}
    for item in string.gmatch(data.pos or "", "([^|]+)") do
        local k,x,y = item:match("^(.+),([^,]+),([^,]+)$")
        if k then DB.iconPositions[UnescapeField(k)] = { x = tonumber(x) or 0, y = tonumber(y) or 0 } end
    end
    local ax, ay = tostring(data.add or "0,0"):match("^([^,]+),([^,]+)$")
    DB.addSlotPosition = { x = tonumber(ax) or 0, y = tonumber(ay) or 0 }
    DB.iconSize = tonumber(data.size) or DB.iconSize or 36
    DB.maxColumns = tonumber(data.cols) or DB.maxColumns or 8
    DB.freeform = true
    if Refresh then Refresh() end
    if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    Print("layout imported")
end

local lastProcAlertAt = {}
local function GetAlertPriority(alertType)
    if alertType == "EXECUTE" then return 3 end
    if alertType == "PROC" then return 2 end
    if alertType == "BUFF" then return 1 end
    return 0
end

local function BuildAlertKey(alertType, label, procAura)
    return tostring(alertType or "?") .. ":" .. string.lower(tostring(label or "?")) .. ":" .. string.lower(tostring(procAura or "?"))
end

local function HideProcAlertFrame()
    local f = EnsureProcAlertFrame()
    f.cwAlertKey = nil
    f.cwAlertPriority = nil
    f.cwAlertType = nil
    f.endTime = nil
    SafeSetScale(f, 1)
    f:SetAlpha(0)
    f:Hide()
end

ShowSingleProcAlert = function(alert)
    if not alert then return end
    local f = EnsureProcAlertFrame()
    local now = GetTime()
    ApplyProcAlertStyle(f)
    SafeSetScale(f, 1)
    f:SetAlpha(1)
    f.icon:SetTexture(alert.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
    f.title:SetText(GetProcRecommendationVerb(alert.alertType))
    ColorProcFont(f.title, alert.alertType)
    ColorProcTexture(f.glow, alert.alertType)
    f.spell:SetText(tostring(alert.label or "Use Now") .. (alert.keybind and (" [" .. tostring(alert.keybind) .. "]") or ""))
    f.cwAlertKey = alert.alertKey
    f.cwAlertPriority = alert.priority
    f.cwAlertType = alert.alertType
    f.endTime = now + ((DB and DB.procPopout) and 1.05 or 0.80)
    f:Show()
    alertCooldowns[alert.alertKey] = now + 1.10
    if alert.playSound then PlayProcSound(alert.alertType) end
end

FireProcAlert = function(button, label, icon, procAura)
    if not DB or not DB.smartProc or not DB.procAlert then return end
    if SuppressProcPopoutForMap and SuppressProcPopoutForMap() then
        if procAlertFrame and procAlertFrame:IsShown() then HideProcAlertFrame() end
        pendingProcAlert = nil
        return
    end

    local now = GetTime()
    local alertType = GetAlertTypeForAura(procAura)
    local alertKey = BuildAlertKey(alertType, label or (button and button.cwLabel), procAura)
    local priority = GetAlertPriority(alertType)
    local f = EnsureProcAlertFrame()

    -- Beta46 alert rules:
    -- One reusable frame only, no stacking, no alert history, no repeated frame creation.
    -- Same spell/type has a short cooldown until its proc state changes off/on.
    -- EXECUTE > PROC > BUFF can replace lower priority immediately.
    if (alertCooldowns[alertKey] or 0) > now then
        return
    end

    local alert = {
        alertType = alertType,
        alertKey = alertKey,
        priority = priority,
        label = label or (button and button.cwLabel) or "Use Now",
        icon = icon or (button and button.icon and button.icon:GetTexture()) or "Interface\\Icons\\INV_Misc_QuestionMark",
        playSound = true,
    }

    if f:IsShown() and f.endTime and f.endTime > now then
        if f.cwAlertKey == alertKey then
            -- Refresh existing alert without replaying the sound.
            alert.playSound = false
            ShowSingleProcAlert(alert)
            return
        end
        if priority < (f.cwAlertPriority or 0) then
            return
        elseif priority == (f.cwAlertPriority or 0) then
            -- Queue equal-priority alerts instead of stacking them. Latest wins.
            pendingProcAlert = alert
            return
        end
        -- Higher priority replaces immediately.
    end

    ShowSingleProcAlert(alert)
end
local function UpdateButtonTimerAndProc(b)
    if not b then return end

    if b.timer then
        if DB and DB.showTimers and b.cwActive and b.cwStart and b.cwDuration and b.cwDuration > 0 then
            local remaining = (b.cwStart + b.cwDuration) - GetTime()
            if remaining > 0 then
                b.timer:ClearAllPoints()
                if b.timerBG then b.timerBG:Show() end

                if remaining <= 10 then
                    b.timer:SetPoint("CENTER", b, "CENTER", 0, 0)
                    if b.timer.SetFont then b.timer:SetFont("Fonts\\FRIZQT__.TTF", math.floor(24 * (DB.timerScale or 1)), "OUTLINE") end
                    b.timer:SetTextColor(1, 0.95, 0.25, 1)
                    if b.timerBG then
                        b.timerBG:SetPoint("CENTER", b, "CENTER", 0, 0)
                        b.timerBG:SetWidth((DB.iconSize or 36) * 0.9)
                        b.timerBG:SetHeight((DB.iconSize or 36) * 0.65)
                        b.timerBG:SetAlpha(0.62)
                    end
                    if remaining <= 3 then
                        SafeSetScale(b.timer, 1 + (math.sin(GetTime() * 12) + 1) * 0.08)
                    else
                        SafeSetScale(b.timer, 1)
                    end
                else
                    b.timer:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -1, 1)
                    if b.timer.SetFont then b.timer:SetFont("Fonts\\FRIZQT__.TTF", math.floor(17 * (DB.timerScale or 1)), "OUTLINE") end
                    b.timer:SetTextColor(1, 1, 1, 1)
                    SafeSetScale(b.timer, 1)
                    if b.timerBG then
                        b.timerBG:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 1, -1)
                        b.timerBG:SetWidth((DB.iconSize or 36) * 0.72)
                        b.timerBG:SetHeight((DB.iconSize or 36) * 0.42)
                        b.timerBG:SetAlpha(0.5)
                    end
                end

                b.timer:SetText(FormatCooldownTime(remaining))
                b.timer:Show()
            else
                b.timer:SetText("")
                b.timer:Hide()
                if b.timerBG then b.timerBG:Hide() end
            end
        else
            b.timer:SetText("")
            b.timer:Hide()
            if b.timerBG then b.timerBG:Hide() end
        end
    end

    local mapAlertSuppressed = SuppressAlertsForMap and SuppressAlertsForMap()

    if b.procGlow then
        if DB and DB.smartProc and DB.procGlow and b.cwProcActive and not mapAlertSuppressed then
            local size = DB.iconSize or 36
            local style = DB.procGlowStyle or 1
            local alertType = b.cwProcType or GetAlertTypeForAura(b.cwProcAura)
            local pulse = DB.procPulse and ((math.sin(GetTime() * 12) + 1) * 0.22) or 0
            if style == 2 then
                b.procGlow:SetTexture("Interface\\Buttons\\UI-Quickslot-Depress")
                b.procGlow:SetWidth(size * (1.65 + pulse))
                b.procGlow:SetHeight(size * (1.65 + pulse))
                b.procGlow:SetAlpha(DB.procPulse and (0.78 + (math.sin(GetTime() * 14) + 1) * 0.12) or 0.95)
            elseif style == 3 then
                b.procGlow:SetTexture("Interface\\SpellActivationOverlay\\IconAlert")
                b.procGlow:SetWidth(size * (2.45 + pulse))
                b.procGlow:SetHeight(size * (2.45 + pulse))
                b.procGlow:SetAlpha(DB.procPulse and (0.74 + (math.sin(GetTime() * 14) + 1) * 0.15) or 0.92)
            else
                b.procGlow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
                b.procGlow:SetWidth(size * (2.95 + pulse))
                b.procGlow:SetHeight(size * (2.95 + pulse))
                b.procGlow:SetAlpha(DB.procPulse and (0.82 + (math.sin(GetTime() * 14) + 1) * 0.13) or 1)
            end
            ColorProcTexture(b.procGlow, alertType)
            b.procGlow:Show()
        else
            b.procGlow:Hide()
        end
    end

    if b.procText then
        if DB and DB.smartProc and b.cwProcActive and not mapAlertSuppressed then
            local alertType = b.cwProcType or GetAlertTypeForAura(b.cwProcAura)
            b.procText:SetText(GetProcRecommendationVerb(alertType) .. (b.cwKeybind and (" [" .. tostring(b.cwKeybind) .. "]") or ""))
            ColorProcFont(b.procText, alertType)
            b.procText:Show()
            if DB.procPulse then
                SafeSetScale(b.procText, 1 + (math.sin(GetTime() * 16) + 1) * 0.08)
            else
                SafeSetScale(b.procText, 1)
            end
        else
            b.procText:SetText("")
            b.procText:Hide()
            SafeSetScale(b.procText, 1)
        end
    end

    if b.keyText then
        -- Beta50b: keybind overlay means "show the bind for this tracked spell".
        -- Earlier Beta50 builds only showed it during an active proc, which made /cw keybinds
        -- look broken on normal cooldown icons.
        if DB and DB.keybindOverlay and b.cwKeybind and not mapAlertSuppressed then
            b.keyText:SetText("[" .. tostring(b.cwKeybind) .. "]")
            b.keyText:Show()
        else
            b.keyText:SetText("")
            b.keyText:Hide()
        end
    end

    if b.readyFlash then
        local now = GetTime()
        if b.cwReadyFlashEnd and b.cwReadyFlashEnd > now then
            local remain = b.cwReadyFlashEnd - now
            b.readyFlash:Show()
            b.readyFlash:SetAlpha(math.min(1, remain * 1.5))
        else
            b.readyFlash:SetAlpha(0)
            b.readyFlash:Hide()
        end
    end
end

local function CreateButton(index)
    local b = CreateFrame("Button", "CoolinatorWrathButton" .. index, CW)
    b:SetWidth(DB.iconSize)
    b:SetHeight(DB.iconSize)
    b:EnableMouse(true)
    b:SetMovable(true)
    b:RegisterForDrag("LeftButton")
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")

    b.icon = b:CreateTexture(nil, "BACKGROUND")
    b.icon:SetAllPoints(b)
    b.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")

    b.cooldown = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
    b.cooldown:SetAllPoints(b)
    b.cooldown:Hide()

    b.timerBG = b:CreateTexture(nil, "OVERLAY")
    b.timerBG:SetTexture(0, 0, 0)
    b.timerBG:SetAlpha(0.6)
    b.timerBG:Hide()

    b.procGlow = b:CreateTexture(nil, "OVERLAY")
    b.procGlow:SetPoint("CENTER", b, "CENTER", 0, 0)
    b.procGlow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    b.procGlow:SetBlendMode("ADD")
    b.procGlow:SetAlpha(0.75)
    b.procGlow:Hide()

    b.readyFlash = b:CreateTexture(nil, "OVERLAY")
    b.readyFlash:SetPoint("CENTER", b, "CENTER", 0, 0)
    b.readyFlash:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    b.readyFlash:SetBlendMode("ADD")
    b.readyFlash:SetAlpha(0)
    b.readyFlash:Hide()

    b.timer = b:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    b.timer:SetPoint("CENTER", b, "CENTER", 0, 0)
    -- High-contrast cooldown numbers: white text, dark outline/shadow.
    if b.timer.SetFont then b.timer:SetFont("Fonts\\FRIZQT__.TTF", 18, "OUTLINE") end
    b.timer:SetTextColor(1, 1, 1, 1)
    if b.timer.SetShadowColor then b.timer:SetShadowColor(0, 0, 0, 1) end
    if b.timer.SetShadowOffset then b.timer:SetShadowOffset(2, -2) end
    b.timer:SetText("")
    b.timer:Hide()

    b.procText = b:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    b.procText:SetPoint("TOP", b, "TOP", 0, 2)
    if b.procText.SetFont then b.procText:SetFont("Fonts\\FRIZQT__.TTF", 14, "OUTLINE") end
    b.procText:SetTextColor(1, 0.82, 0.12, 1)
    b.procText:SetText("")
    b.procText:Hide()

    b.keyText = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    b.keyText:SetPoint("BOTTOM", b, "BOTTOM", 0, -1)
    if b.keyText.SetFont then b.keyText:SetFont("Fonts\FRIZQT__.TTF", 11, "OUTLINE") end
    b.keyText:SetTextColor(1, 1, 1, 1)
    b.keyText:SetText("")
    b.keyText:Hide()

    b.count = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    b.count:SetPoint("CENTER", b, "CENTER", 0, 0)
    b.count:SetText("")

    -- No visible text under the icon. Tooltips identify the tracked object.
    b.label = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    b.label:SetPoint("TOP", b, "BOTTOM", 0, -1)
    b.label:SetText("")

    b:SetScript("OnDragStart", function(self)
        if DB and not DB.locked then
            if IsShiftKeyDown and IsShiftKeyDown() then
                dragging = true
                CW:StartMoving()
            else
                draggingButton = self
                local cx, cy = GetCursorPosition()
                local scale = UIParent:GetScale() or 1
                self.cwDragStartCursorX = cx / scale
                self.cwDragStartCursorY = cy / scale
                local p = DB.iconPositions and DB.iconPositions[self.cwObjKey]
                self.cwDragStartX = (p and p.x) or 0
                self.cwDragStartY = (p and p.y) or 0
            end
        end
    end)
    b:SetScript("OnUpdate", function(self)
        if draggingButton == self and DB and DB.freeform and self.cwObjKey then
            local cx, cy = GetCursorPosition()
            local scale = UIParent:GetScale() or 1
            cx = cx / scale
            cy = cy / scale
            local dx = cx - (self.cwDragStartCursorX or cx)
            local dy = cy - (self.cwDragStartCursorY or cy)

            DB.iconPositions = DB.iconPositions or {}
            DB.iconPositions[self.cwObjKey] = {
                x = SnapValue((self.cwDragStartX or 0) + dx),
                y = SnapValue((self.cwDragStartY or 0) + dy)
            }

            local pos = DB.iconPositions[self.cwObjKey]
            self:ClearAllPoints()
            self:SetPoint("TOPLEFT", CW, "TOPLEFT", pos.x, pos.y)
        end
        UpdateButtonTimerAndProc(self)
    end)
    b:SetScript("OnDragStop", function(self)
        ForceStopDragging()
        if Refresh then Refresh() end
    end)
    b:SetScript("OnMouseDown", function(self, button)
        -- Left-click without dragging should not move anything.
    end)
    b:SetScript("OnMouseUp", function(self, button)
        if button == "RightButton" then
            if DB and not DB.locked and self.cwObjKey and RemoveTrackedObjectByKey then
                RemoveTrackedObjectByKey(self.cwObjKey)
            end
            return
        end
        if GetCursorInfo() then
            if AddCursorToTracker then AddCursorToTracker() end
        end
    end)
    b:SetScript("OnReceiveDrag", function(self)
        if AddCursorToTracker then AddCursorToTracker() end
    end)

    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(self.cwLabel or "Coolinator-Wrath")
        if self.cwDetail then GameTooltip:AddLine(self.cwDetail, 1, 1, 1) end
        if DB and not DB.locked then
            GameTooltip:AddLine("Right-click to remove from tracking.", 0.8, 0.8, 0.8)
            GameTooltip:AddLine("Drag to move. Shift-drag to move the whole group.", 0.8, 0.8, 0.8)
        end
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)

    buttons[index] = b
    return b
end


local function CreateAddSlot()
    if addSlot then return addSlot end

    addSlot = CreateFrame("Button", "CoolinatorWrathAddSlot", CW)
    addSlot:SetWidth(DB.iconSize or 36)
    addSlot:SetHeight(DB.iconSize or 36)
    addSlot:EnableMouse(true)
    addSlot:SetMovable(true)
    addSlot:RegisterForDrag("LeftButton")

    addSlot.bg = addSlot:CreateTexture(nil, "BACKGROUND")
    addSlot.bg:SetAllPoints(addSlot)
    addSlot.bg:SetTexture("Interface\\Buttons\\UI-Quickslot2")
    addSlot.bg:SetAlpha(0.85)

    addSlot.plus = addSlot:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    addSlot.plus:SetPoint("CENTER", addSlot, "CENTER", 0, 0)
    addSlot.plus:SetText("|cff66ccff+|r")

    addSlot:SetScript("OnReceiveDrag", function(self)
        if AddCursorToTracker then AddCursorToTracker() end
        if Refresh then Refresh() end
    end)
    addSlot:SetScript("OnMouseUp", function(self)
        if GetCursorInfo and GetCursorInfo() then
            if AddCursorToTracker then AddCursorToTracker() end
        end
        local wasDraggingPlus = (draggingButton == self)
        ForceStopDragging()
        SaveAddSlotPosition(wasDraggingPlus)
        if Refresh then Refresh() end
    end)
    addSlot:SetScript("OnDragStart", function(self)
        if DB and not DB.locked then
            if IsShiftKeyDown and IsShiftKeyDown() then
                dragging = true
                CW:StartMoving()
            else
                draggingButton = self
                local cx, cy = GetCursorPosition()
                local scale = UIParent:GetScale() or 1
                self.cwDragStartCursorX = cx / scale
                self.cwDragStartCursorY = cy / scale
                DB.addSlotAuto = false
                local p = DB.addSlotPosition or { x = 0, y = 0 }
                self.cwDragStartX = p.x or 0
                self.cwDragStartY = p.y or 0
            end
        end
    end)
    addSlot:SetScript("OnUpdate", function(self)
        if draggingButton == self and DB and DB.freeform then
            local cx, cy = GetCursorPosition()
            local scale = UIParent:GetScale() or 1
            cx = cx / scale
            cy = cy / scale
            local dx = cx - (self.cwDragStartCursorX or cx)
            local dy = cy - (self.cwDragStartCursorY or cy)

            DB.addSlotPosition = DB.addSlotPosition or { x = 0, y = 0 }
            DB.addSlotPosition.x = SnapValue((self.cwDragStartX or 0) + dx)
            DB.addSlotPosition.y = SnapValue((self.cwDragStartY or 0) + dy)

            self:ClearAllPoints()
            self:SetPoint("TOPLEFT", CW, "TOPLEFT", DB.addSlotPosition.x, DB.addSlotPosition.y)
        end
    end)
    addSlot:SetScript("OnDragStop", function(self)
        ForceStopDragging()
        SaveAddSlotPosition(true)
        if Refresh then Refresh() end
    end)
    addSlot:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Coolinator-Wrath")
        GameTooltip:AddLine("Drop a spell or item here.", 1, 1, 1)
        GameTooltip:AddLine("Drag this + slot to choose where the next icon lands.", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Shift-drag to move the whole group.", 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    addSlot:SetScript("OnLeave", function() GameTooltip:Hide() end)

    addSlot:Hide()
    return addSlot
end

local function LayoutButtons()
    local size = DB.iconSize or 36
    local spacing = DB.spacing or 4
    local cols = DB.maxColumns or 8
    local shownIndex = 0
    local dir = (DB and DB.growDirection) or "RIGHT"

    local function SlotXY(index)
        local n = index - 1
        if dir == "LEFT" then
            local row = math.floor(n / cols)
            local col = n % cols
            return -col * (size + spacing), -row * (size + spacing)
        elseif dir == "UP" then
            return 0, n * (size + spacing)
        elseif dir == "DOWN" then
            return 0, -n * (size + spacing)
        else
            local row = math.floor(n / cols)
            local col = n % cols
            return col * (size + spacing), -row * (size + spacing)
        end
    end

    local function Place(frame, x, y)
        frame:ClearAllPoints()
        frame:SetPoint("TOPLEFT", CW, "TOPLEFT", x, y)
        frame:SetWidth(size)
        frame:SetHeight(size)
    end

    -- In freeform, the parent is a fixed invisible canvas. It must not resize around icons.
    if DB and DB.freeform then
        CW:SetWidth(DB.canvasWidth or 600)
        CW:SetHeight(DB.canvasHeight or 400)
    end

    for i, b in ipairs(buttons) do
        b:ClearAllPoints()
        b:SetWidth(size)
        b:SetHeight(size)
        if b.procGlow then
            b.procGlow:SetWidth(size * 2.55)
            b.procGlow:SetHeight(size * 2.55)
        end
        if b.readyFlash then
            b.readyFlash:SetWidth(size * 1.9)
            b.readyFlash:SetHeight(size * 1.9)
        end
        UpdateDesignerVisuals(b)

        if b:IsShown() then
            shownIndex = shownIndex + 1

            if DB and DB.freeform then
                local key = b.cwObjKey
                local pos = key and DB.iconPositions and DB.iconPositions[key]
                local x, y

                if pos then
                    x = pos.x or 0
                    y = pos.y or 0
                else
                    x, y = SlotXY(shownIndex)
                    if key then
                        DB.iconPositions = DB.iconPositions or {}
                        DB.iconPositions[key] = { x = x, y = y }
                    end
                end

                Place(b, x, y)
            else
                local x, y = SlotXY(shownIndex)
                Place(b, x, y)
            end
        else
            b:SetPoint("TOPLEFT", CW, "TOPLEFT", 0, 0)
        end
    end

    CreateAddSlot()
    if DB and not DB.locked and DB.enabled then
        local x, y
        if DB.freeform then
            -- Do not recalculate the + slot on every layout refresh.
            -- Recalculating here makes manually dragging + appear to snap back.
            DB.addSlotPosition = DB.addSlotPosition or { x = shownIndex * (size + spacing), y = 0 }
            x = DB.addSlotPosition.x or 0
            y = DB.addSlotPosition.y or 0
        else
            x, y = SlotXY(shownIndex + 1)
        end

        Place(addSlot, x, y)
        UpdateDesignerVisuals(addSlot)
        addSlot:SetFrameLevel(80)
        addSlot:Show()
    else
        UpdateDesignerVisuals(addSlot)
        addSlot:Hide()
    end

    if not (DB and DB.freeform) then
        local visibleCount = math.max(shownIndex + ((DB and not DB.locked and DB.enabled) and 1 or 0), 1)
        if dir == "UP" or dir == "DOWN" then
            CW:SetWidth(size)
            CW:SetHeight(math.max(size, visibleCount * (size + spacing)))
        else
            local rows = math.max(1, math.ceil(visibleCount / cols))
            local usedCols = math.min(cols, visibleCount)
            CW:SetWidth(math.max(size, usedCols * (size + spacing)))
            CW:SetHeight(math.max(size, rows * (size + spacing)))
        end
    end
end

local function EnsureButtons(countOverride)
    local count = countOverride
    if count == nil then
        count = testMode and 5 or table.getn(objects)
    end
    count = math.max(0, count or 0)

    for i = 1, count do
        if not buttons[i] then CreateButton(i) end
    end

    for i, b in ipairs(buttons) do
        if i <= count then
            if not b:IsShown() then b:Show() end
        else
            if b:IsShown() then b:Hide() end
        end
    end

    LayoutButtons()
end

local function SetButtonState(b, icon, label, active, start, duration, count, detail, procActive, procAura, keybind)
    -- A proc highlight is only useful while the spell is ready to be pressed.
    -- Once the tracked spell goes on cooldown, immediately clear USE/glow/pulse even if the aura scan is briefly stale.
    if active and duration and duration > 1.5 and start and start > 0 then
        procActive = false
        procAura = nil
    end

    local stateKey = table.concat({
        tostring(icon or ""),
        tostring(label or ""),
        tostring(active or false),
        tostring(math.floor((start or 0) * 10)),
        tostring(math.floor((duration or 0) * 10)),
        tostring(count or ""),
        tostring(detail or ""),
        tostring(procActive or false),
        tostring(procAura or ""),
        tostring(keybind or "")
    }, "|")

    if b.cwStateKey == stateKey then
        return
    end
    local wasProcActive = b.cwProcActive
    b.cwStateKey = stateKey

    b.icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_QuestionMark")
    b.label:SetText("")
    b.count:SetText((count and count > 1) and tostring(count) or "")
    b.cwLabel = label
    b.cwDetail = detail
    b.cwActive = active
    b.cwStart = start or 0
    b.cwDuration = duration or 0
    b.cwProcActive = procActive
    b.cwProcAura = procAura
    b.cwKeybind = keybind
    b.cwProcType = procAura and GetAlertTypeForAura(procAura) or nil

    if procActive then
        b.cwDetail = tostring(detail or label or "") .. "\nProc active: " .. tostring(procAura or "")
        if not wasProcActive and FireProcAlert then
            FireProcAlert(b, label, icon, procAura)
        end
    end

    if active and duration and duration > 0 and start then
        b.cooldown:Show()
        b.cooldown:SetCooldown(start, duration)
        b.icon:SetVertexColor(1, 1, 1, 1)
    else
        -- Ready icons should look like normal action bar buttons: full color, no cooldown swipe.
        -- Do not spam SetCooldown(0,0); some 3.3.5 clients flicker when this is reset repeatedly.
        b.cooldown:Hide()
        b.icon:SetVertexColor(1, 1, 1, 1)
    end
    UpdateButtonTimerAndProc(b)
end

local function ShortLabel(s)
    if not s then return "" end
    if string.len(s) <= 8 then return s end
    return string.sub(s, 1, 8)
end

local function IsTrackedSpellName(spellName)
    if not spellName or not DB then return false end
    local wanted = string.lower(tostring(spellName))
    for _, v in ipairs(DB.spells or {}) do
        local _, name = GetSpellKey(tostring(v))
        if name and string.lower(tostring(name)) == wanted then return true end
        if string.lower(tostring(v)) == wanted then return true end
    end
    return false
end

local function FireAutoProcAlerts(visibleProcSpells)
    if not DB or not DB.smartProc or not DB.procAlert or not DB.autoProcAlert then return end
    if not currentProcCandidates then return end

    local now = GetTime()
    for _, candidate in ipairs(currentProcCandidates) do
        if candidate and candidate.primary and candidate.spell and candidate.aura then
            local spellName = tostring(candidate.spell)
            local spellKey = string.lower(spellName)
            local alertKey = NormalizeProcName(candidate.aura) .. ":" .. spellKey
            local alreadyVisible = visibleProcSpells and visibleProcSpells[spellKey]
            if (not alreadyVisible) and (not IsTrackedSpellName(spellName)) and ((lastAutoProcAlert[alertKey] or 0) + 2.0 <= now) then
                local resolved, _, icon = GetSpellInfo(spellName)
                FireProcAlert(nil, resolved or spellName, icon or candidate.icon or EXECUTE_ICON_FALLBACKS[spellName] or "Interface\\Icons\\INV_Misc_QuestionMark", candidate.aura)
                lastAutoProcAlert[alertKey] = now
                if DB.procDebug then Print("AUTO PROC ALERT: " .. tostring(candidate.aura) .. " -> " .. tostring(resolved or spellName)) end
                return
            end
        end
    end
end

local function UpdateTracker()
    if not DB or not DB.enabled then return end

    if testMode then
        EnsureButtons(5)
        local icons = {
            "Interface\\Icons\\Spell_Nature_Rejuvenation",
            "Interface\\Icons\\Spell_Holy_FlashHeal",
            "Interface\\Icons\\Ability_Warrior_Charge",
            "Interface\\Icons\\INV_Potion_54",
            "Interface\\Icons\\Spell_Frost_FrostBolt02",
        }
        for i = 1, 5 do
            local b = buttons[i]
            if procTestMode and i == 2 then
                SetButtonState(b, "Interface\\Icons\\Spell_Holy_Excorcism_02", "Exorcism", false, 0, 0, nil, "Alert visual test", true, (procTestIndex == 3 and "Target <= 20% HP") or (procTestIndex == 2 and "Infusion of Light") or "The Art of War")
            elseif i == 1 then
                SetButtonState(b, icons[i], "Ready Flash", false, 0, 0, nil, "Ready flash test")
                b.cwReadyFlashEnd = GetTime() + 1.0
            else
                SetButtonState(b, icons[i], "Test" .. i, true, GetTime() - i * 3, 30 + i * 5, nil, "Cooldown number test")
            end
        end
        if UpdateHotbarProcHighlights then UpdateHotbarProcHighlights(procTestMode and { ["exorcism"] = "Test Proc" } or {}) end
        return
    end

    local visible = {}
    local visibleProcSpells = {}
    local activeProcTargets = BuildActiveProcTargets()
    if UpdateHotbarProcHighlights then UpdateHotbarProcHighlights(activeProcTargets) end
    for i, obj in ipairs(objects) do
        if obj.kind == "spell" then
            local name, _, icon = GetSpellInfo(obj.key)
            local start, duration, enabled = GetSpellCooldown(obj.key)
            local procAura = GetProcAuraForSpell(name or obj.label, activeProcTargets)
            if procAura and name then visibleProcSpells[string.lower(tostring(name))] = true end
            -- Only show real cooldowns by default. This intentionally filters out the global cooldown.
            if enabled == 1 and duration and duration > 1.5 and start and start > 0 then
                table.insert(visible, {
                    icon = icon or obj.icon,
                    label = name or obj.label,
                    active = true,
                    start = start,
                    duration = duration,
                    count = nil,
                    detail = name or obj.label,
                    objKey = ObjKey(obj),
                    -- Do not keep proc visuals active after the highlighted spell has been used.
                    -- If the spell is now cooling down, the proc has effectively been acted on.
                    procActive = false,
                    procAura = nil,
                    keybind = GetKeybindForSpell(name or obj.label)
                })
            elseif DB.showReady or (DB and not DB.locked) or procAura then
                table.insert(visible, {
                    icon = icon or obj.icon,
                    label = name or obj.label,
                    active = false,
                    start = 0,
                    duration = 0,
                    count = nil,
                    detail = procAura and ("Proc-ready spell: " .. tostring(procAura)) or "Ready / tracked spell",
                    objKey = ObjKey(obj),
                    procActive = procAura ~= nil,
                    procAura = procAura,
                    keybind = GetKeybindForSpell(name or obj.label)
                })
            end
        elseif obj.kind == "item" then
            local name, _, _, _, _, _, _, _, _, icon = GetItemInfo(obj.key)
            local start, duration, enabled = GetItemCooldown(obj.key)
            if enabled == 1 and duration and duration > 1.5 and start and start > 0 then
                table.insert(visible, {
                    icon = icon or obj.icon,
                    label = name or obj.label,
                    active = true,
                    start = start,
                    duration = duration,
                    count = nil,
                    detail = name or obj.label,
                    objKey = ObjKey(obj)
                })
            elseif DB.showReady or (DB and not DB.locked) then
                table.insert(visible, {
                    icon = icon or obj.icon,
                    label = name or obj.label,
                    active = false,
                    start = 0,
                    duration = 0,
                    count = nil,
                    detail = "Ready / tracked item",
                    objKey = ObjKey(obj)
                })
            end
        elseif obj.kind == "equipment" then
            local slot = tonumber(obj.key)
            local icon = slot and GetInventoryItemTexture and GetInventoryItemTexture("player", slot)
            local link = slot and GetInventoryItemLink and GetInventoryItemLink("player", slot)
            local name = obj.label
            if link and GetItemInfo then
                local itemName = GetItemInfo(link)
                if itemName then name = itemName end
            end
            local start, duration, enabled = 0, 0, 0
            if slot and GetInventoryItemCooldown then
                start, duration, enabled = GetInventoryItemCooldown("player", slot)
            end
            if enabled == 1 and duration and duration > 1.5 and start and start > 0 then
                table.insert(visible, { icon = icon or obj.icon, label = obj.label, active = true, start = start, duration = duration, count = nil, detail = tostring(obj.label) .. (name and ("\n" .. tostring(name)) or ""), objKey = ObjKey(obj) })
            elseif DB.showReady or (DB and not DB.locked) then
                table.insert(visible, { icon = icon or obj.icon, label = obj.label, active = false, start = 0, duration = 0, count = nil, detail = tostring(obj.label) .. " / tracked equipment" .. (name and ("\n" .. tostring(name)) or ""), objKey = ObjKey(obj) })
            end
        elseif obj.kind == "aura" then
            local name, icon, count, duration, expiration = FindPlayerAura(obj.key)
            if name then
                local start = 0
                if duration and duration > 0 and expiration and expiration > 0 then
                    start = expiration - duration
                end
                table.insert(visible, {
                    icon = icon,
                    label = name,
                    active = true,
                    start = start,
                    duration = duration,
                    count = count,
                    detail = name or obj.key,
                    objKey = ObjKey(obj)
                })
            end
        end
    end

    FireAutoProcAlerts(visibleProcSpells)

    EnsureButtons(table.getn(visible))
    for i, data in ipairs(visible) do
        if buttons[i] then
            buttons[i].cwObjKey = data.objKey
        end
        SetButtonState(buttons[i], data.icon, data.label, data.active, data.start, data.duration, data.count, data.detail, data.procActive, data.procAura, data.keybind)
    end
    LayoutButtons()
end

Refresh = function()
    RebuildObjects()
    for _, b in ipairs(buttons) do
        b.cwStateKey = nil
    end
    EnsureButtons()
    UpdateTracker()
end


local refreshQueued = false
local function RequestRefresh()
    refreshQueued = true
end

local function AddSpell(input)
    local key, name = GetSpellKey(input)
    if not key then Print("Spell not found: " .. tostring(input)); return end
    for _, v in ipairs(DB.spells) do
        if tostring(v) == tostring(key) or string.lower(tostring(v)) == string.lower(tostring(name)) then
            Print("Already tracking spell: " .. name)
            if Refresh then Refresh() end
            if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
            return
        end
    end
    table.insert(DB.spells, key)
    DB.iconPositions = DB.iconPositions or {}
    DB.iconPositions["spell:" .. tostring(key)] = { x = (DB.addSlotPosition and DB.addSlotPosition.x) or 0, y = (DB.addSlotPosition and DB.addSlotPosition.y) or 0 }
    AdvanceAddSlot()
    Print("Added spell: " .. name .. " (shows when on cooldown; /cw ready toggles ready icons)")
    if Refresh then Refresh() end
    if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    if dropZone then dropZone:Hide() end
end

local function AddItem(input)
    local key, name = GetItemKey(input)
    if not key then Print("Item not found: " .. tostring(input)); return end
    for _, v in ipairs(DB.items) do
        if tostring(v) == tostring(key) or string.lower(tostring(v)) == string.lower(tostring(name)) then
            Print("Already tracking item: " .. name)
            if Refresh then Refresh() end
            if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
            return
        end
    end
    table.insert(DB.items, key)
    DB.iconPositions = DB.iconPositions or {}
    DB.iconPositions["item:" .. tostring(key)] = { x = (DB.addSlotPosition and DB.addSlotPosition.x) or 0, y = (DB.addSlotPosition and DB.addSlotPosition.y) or 0 }
    AdvanceAddSlot()
    Print("Added item: " .. name .. " (shows when on cooldown; /cw ready toggles ready icons)")
    if Refresh then Refresh() end
    if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    if dropZone then dropZone:Hide() end
end

local function AddAura(input)
    input = Trim(input)
    if input == "" then Print("Usage: /cw addaura <aura name>"); return end
    for _, v in ipairs(DB.auras) do
        if string.lower(tostring(v)) == string.lower(input) then
            Print("Already tracking aura: " .. input)
            if Refresh then Refresh() end
            if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
            return
        end
    end
    table.insert(DB.auras, input)
    Print("Added player aura: " .. input)
    if Refresh then Refresh() end
    if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
end

local EQUIPMENT_SLOT_ALIASES = { trinket1 = 13, trinket = 13, toptrinket = 13, trinkettop = 13, trinket2 = 14, bottomtrinket = 14, trinketbottom = 14, gloves = 10, glove = 10, hands = 10, engineeringgloves = 10 }

local function ResolveEquipmentSlot(input)
    local raw = Trim(input or "")
    if raw == "" then return nil end
    local key = string.lower(raw):gsub("[%s%-%_]+", "")
    return EQUIPMENT_SLOT_ALIASES[key] or tonumber(raw)
end

local function EquipmentSlotLabel(slot)
    slot = tonumber(slot)
    if slot == 13 then return "Trinket 1" end
    if slot == 14 then return "Trinket 2" end
    if slot == 10 then return "Gloves" end
    return "Equipment Slot " .. tostring(slot)
end

local function AddEquipmentSlot(input)
    local slot = ResolveEquipmentSlot(input)
    if not slot then Print("Usage: /cw equip trinket1|trinket2|gloves"); return end
    DB.equipmentSlots = DB.equipmentSlots or {}
    for _, v in ipairs(DB.equipmentSlots) do
        if tonumber(v) == tonumber(slot) then Print("Already tracking equipment: " .. EquipmentSlotLabel(slot)); if Refresh then Refresh() end; return end
    end
    table.insert(DB.equipmentSlots, slot)
    DB.iconPositions = DB.iconPositions or {}
    DB.iconPositions["equipment:" .. tostring(slot)] = { x = (DB.addSlotPosition and DB.addSlotPosition.x) or 0, y = (DB.addSlotPosition and DB.addSlotPosition.y) or 0 }
    AdvanceAddSlot()
    Print("Added equipment: " .. EquipmentSlotLabel(slot))
    if Refresh then Refresh() end
    if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
end

local function RemoveEquipmentSlot(input)
    local slot = ResolveEquipmentSlot(input)
    if not slot then Print("Usage: /cw removeequip trinket1|trinket2|gloves"); return end
    for i = table.getn(DB.equipmentSlots or {}), 1, -1 do
        if tonumber(DB.equipmentSlots[i]) == tonumber(slot) then
            table.remove(DB.equipmentSlots, i)
            if DB.iconPositions then DB.iconPositions["equipment:" .. tostring(slot)] = nil end
            NormalizeAddSlotAfterRemoval()
            Print("Removed equipment: " .. EquipmentSlotLabel(slot))
            if Refresh then Refresh() end
            if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
            return
        end
    end
    Print("Not tracking equipment: " .. EquipmentSlotLabel(slot))
end

local function SetDefaults()
    CoolinatorWrathDB = CopyDefaults(DEFAULTS, {})
    DB = CoolinatorWrathDB
    NormalizeSavedOptions()
    MarkHotbarCacheDirty()
end


local function AddFromCursor(kind)
    local cursorType, arg1, arg2 = GetCursorInfo()
    if not cursorType then
        Print("Drag a spell from your spellbook or an item from your bags/equipment onto this box.")
        return
    end

    if kind == "spell" then
        if cursorType == "spell" then
            local id = arg1 or arg2
            local name = id and GetSpellInfo(id)
            -- Some 3.3.5 clients return spellbook slot/bookType instead of spellID.
            -- For spellbook drops, storing the resolved name is often safer than storing the slot number.
            if arg1 and arg2 and GetSpellName then
                local bookName = GetSpellName(arg1, arg2)
                if bookName then
                    name = bookName
                    id = bookName
                end
            end
            AddSpell(tostring(name or id or ""))
            ClearCursor()
            if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
        else
            Print("That is not a spell. Drag a spell from your spellbook.")
            ClearCursor()
        end
    elseif kind == "item" then
        if cursorType == "item" then
            local item = arg1 or arg2
            if type(item) == "string" then
                local itemId = item:match("item:(%d+)")
                AddItem(tostring(itemId or item))
            else
                AddItem(tostring(item or ""))
            end
            ClearCursor()
        else
            Print("That is not an item. Drag an item from your bags/equipment.")
            ClearCursor()
        end
    end
end

local function NewDropBox(parent, name, text, x, y, kind)
    local b = CreateFrame("Button", name, parent)
    b:SetWidth(170)
    b:SetHeight(38)
    b:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    b:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 }
    })
    b:SetBackdropColor(0, 0, 0, 0.65)
    b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.text:SetPoint("CENTER", b, "CENTER", 0, 0)
    b.text:SetWidth(155)
    b.text:SetText(text)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:SetScript("OnReceiveDrag", function() AddCursorToTracker(); if dropZone then dropZone:Hide() end end)
    b:SetScript("OnMouseUp", function() AddCursorToTracker(); if dropZone then dropZone:Hide() end end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(text)
        GameTooltip:AddLine("Drop here to add it to tracking.", 1, 1, 1)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return b
end

local function OpenSpellbook()
    if ToggleSpellBook then
        ToggleSpellBook(BOOKTYPE_SPELL)
    elseif SpellBookFrame then
        if SpellBookFrame:IsShown() then
            HideUIPanel(SpellBookFrame)
        else
            ShowUIPanel(SpellBookFrame)
        end
    else
        Print("Spellbook frame not available on this client.")
    end
end



local function EnsureDragHandle()
    if dragHandle then return dragHandle end

    -- In unlocked mode this becomes a subtle placement/edit border, not a giant label.
    dragHandle = CreateFrame("Frame", "CoolinatorWrathEditBorder", CW)
    dragHandle:SetPoint("TOPLEFT", CW, "TOPLEFT", -4, 4)
    dragHandle:SetPoint("BOTTOMRIGHT", CW, "BOTTOMRIGHT", 4, -4)
    dragHandle:SetBackdrop({
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 10,
        insets = { left = 2, right = 2, top = 2, bottom = 2 }
    })
    dragHandle:EnableMouse(false)
    dragHandle:Hide()
    return dragHandle
end

local function UpdateDragHandle()
    EnsureDragHandle()
    if DB and not DB.locked then
        dragHandle:Hide()
    else
        dragHandle:Hide()
    end
end




local function EnsureDropZone()
    if dropZone then return dropZone end

    -- Designer drop target: small, actionbar-like empty slot. This is the only edit visual.
    dropZone = CreateFrame("Button", "CoolinatorWrathDropZone", UIParent)
    dropZone:SetWidth(DB and DB.iconSize or 36)
    dropZone:SetHeight(DB and DB.iconSize or 36)
    dropZone:SetFrameStrata("DIALOG")
    dropZone:SetBackdrop({
        bgFile = "Interface\\Buttons\\UI-Quickslot2",
        edgeFile = "Interface\\Buttons\\UI-Quickslot-Depress",
        tile = false, edgeSize = 12,
        insets = { left = 2, right = 2, top = 2, bottom = 2 }
    })
    dropZone.icon = dropZone:CreateTexture(nil, "ARTWORK")
    dropZone.icon:SetPoint("CENTER", dropZone, "CENTER", 0, 0)
    dropZone.icon:SetWidth(22)
    dropZone.icon:SetHeight(22)
    dropZone.icon:SetTexture("Interface\\Buttons\\UI-GroupLoot-Pass-Up")
    dropZone.icon:SetAlpha(0.65)

    dropZone:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    dropZone:SetScript("OnReceiveDrag", function(self)
        if AddCursorToTracker then AddCursorToTracker() end
        self:Hide()
        if Refresh then Refresh() end
    end)
    dropZone:SetScript("OnMouseUp", function(self)
        if AddCursorToTracker then AddCursorToTracker() end
        self:Hide()
        if Refresh then Refresh() end
    end)
    dropZone:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Coolinator-Wrath")
        GameTooltip:AddLine("Drop a spell or item here.", 1, 1, 1)
        GameTooltip:Show()
    end)
    dropZone:SetScript("OnLeave", function() GameTooltip:Hide() end)
    dropZone:Hide()
    return dropZone
end

local function IsCursorTrackable()
    if GetCursorInfo then
        local cursorType = GetCursorInfo()
        if cursorType == "spell" or cursorType == "item" then return true end
    end
    if CursorHasItem and CursorHasItem() then return true end
    if CursorHasSpell and CursorHasSpell() then return true end
    return false
end

local function PositionDropZone()
    EnsureDropZone()
    dropZone:ClearAllPoints()

    local size = DB and DB.iconSize or 36
    local spacing = DB and DB.spacing or 4
    local dir = (DB and DB.growDirection) or "RIGHT"
    local count = table.getn(objects or {})

    dropZone:SetWidth(size)
    dropZone:SetHeight(size)

    -- If there are no icons yet, sit exactly where the first icon will appear.
    if count < 1 then
        dropZone:SetPoint("CENTER", CW, "CENTER", 0, 0)
        return
    end

    -- Otherwise appear just past the current group in the chosen grow direction.
    if dir == "LEFT" then
        dropZone:SetPoint("CENTER", CW, "LEFT", -(size + spacing), 0)
    elseif dir == "UP" then
        dropZone:SetPoint("CENTER", CW, "TOP", 0, size + spacing)
    elseif dir == "DOWN" then
        dropZone:SetPoint("CENTER", CW, "BOTTOM", 0, -(size + spacing))
    else
        dropZone:SetPoint("CENTER", CW, "RIGHT", size + spacing, 0)
    end
end

local function UpdateDropZone()
    EnsureDropZone()
    if not DB or DB.locked or not DB.editDropZone then
        dropZone:Hide()
        return
    end

    local trackedCount = table.getn(objects or {})
    local shouldShow = false

    -- Always show a small empty slot while unlocked if nothing exists yet.
    if DB.emptySlotDrop and trackedCount < 1 then
        shouldShow = true
    elseif IsCursorTrackable() then
        shouldShow = true
    end

    if shouldShow then
        PositionDropZone()
        dropZone:Hide()
    else
        dropZone:Hide()
    end
end


local function CreateConfigFrame()
    if ConfigFrame then return ConfigFrame end
    local f = CreateFrame("Frame", "CoolinatorWrathConfigFrame", UIParent)
    f:SetWidth(620)
    f:SetHeight(665)
    f:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    f:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 }
    })
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(self) self:StartMoving() end)
    f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    f:Hide()
    table.insert(UISpecialFrames, "CoolinatorWrathConfigFrame")

    f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    f.title:SetPoint("TOP", f, "TOP", 0, -18)
    f.title:SetText("Coolinator-Wrath")

    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", f, "TOPRIGHT", -5, -5)

    local function NewButton(name, text, x, y, w, h)
        local b = CreateFrame("Button", name, f, "UIPanelButtonTemplate")
        b:SetWidth(w or 92)
        b:SetHeight(h or 22)
        b:SetPoint("TOPLEFT", f, "TOPLEFT", x, y)
        b:SetText(text)
        return b
    end

    local function NewHeader(text, x, y)
        local h = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        h:SetPoint("TOPLEFT", f, "TOPLEFT", x, y)
        h:SetText("|cffffd200" .. text .. "|r")
        return h
    end

    local function NewStatus(x, y, w, h)
        local fs = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        fs:SetPoint("TOPLEFT", f, "TOPLEFT", x, y)
        fs:SetWidth(w or 260)
        fs:SetHeight(h or 120)
        fs:SetJustifyH("LEFT")
        fs:SetJustifyV("TOP")
        return fs
    end

    local info = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    info:SetPoint("TOPLEFT", f, "TOPLEFT", 28, -50)
    info:SetWidth(560)
    info:SetJustifyH("LEFT")
    info:SetText("Drag spells/items onto the drop boxes or the unlocked + slot. Right-click tracked icons while unlocked to remove them.")

    NewHeader("Add Tracking", 30, -82)
    NewDropBox(f, "CoolinatorWrathSpellDrop", "Drop Spell Cooldown", 30, -105, "spell")
    NewDropBox(f, "CoolinatorWrathItemDrop", "Drop Item Cooldown", 215, -105, "item")
    local openBook = NewButton(nil, "Open Spellbook", 405, -105, 145, 24)
    openBook:SetScript("OnClick", OpenSpellbook)

    f.input = CreateFrame("EditBox", "CoolinatorWrathConfigInput", f, "InputBoxTemplate")
    f.input:SetWidth(360)
    f.input:SetHeight(20)
    f.input:SetPoint("TOPLEFT", f, "TOPLEFT", 30, -153)
    f.input:SetAutoFocus(false)
    f.input:SetText("")
    f.input:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    f.input:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    NewButton(nil, "Add Spell", 405, -149, 85, 22):SetScript("OnClick", function() AddSpell(f.input:GetText()); f.input:SetText("") end)
    NewButton(nil, "Add Item", 495, -149, 85, 22):SetScript("OnClick", function() AddItem(f.input:GetText()); f.input:SetText("") end)
    NewButton(nil, "Add Aura", 405, -177, 85, 22):SetScript("OnClick", function() AddAura(f.input:GetText()); f.input:SetText("") end)
    NewButton(nil, "Clear All", 495, -177, 85, 22):SetScript("OnClick", function() DB.spells = {}; DB.items = {}; DB.equipmentSlots = {}; DB.auras = {}; DB.iconPositions = {}; if Refresh then Refresh() end; Print("tracking cleared"); if f.RefreshText then f.RefreshText() end end)

    NewHeader("Layout", 30, -215)
    f.sizeLabel = NewStatus(30, -238, 130, 20)
    NewButton(nil, "Icon -", 165, -235, 65, 22):SetScript("OnClick", function() DB.iconSize = math.max(20, (DB.iconSize or 36) - 2); if Refresh then Refresh() end; if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Icon +", 235, -235, 65, 22):SetScript("OnClick", function() DB.iconSize = math.min(80, (DB.iconSize or 36) + 2); if Refresh then Refresh() end; if f.RefreshText then f.RefreshText() end end)
    f.colsLabel = NewStatus(30, -266, 130, 20)
    NewButton(nil, "Cols -", 165, -263, 65, 22):SetScript("OnClick", function() DB.maxColumns = math.max(1, (DB.maxColumns or 8) - 1); if Refresh then Refresh() end; if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Cols +", 235, -263, 65, 22):SetScript("OnClick", function() DB.maxColumns = math.min(20, (DB.maxColumns or 8) + 1); if Refresh then Refresh() end; if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Unlock", 315, -235, 75, 22):SetScript("OnClick", function() DB.locked = false; UpdateDragHandle(); if Refresh then Refresh() end; Print("designer mode enabled") end)
    NewButton(nil, "Lock", 315, -263, 75, 22):SetScript("OnClick", function() DB.locked = true; UpdateDragHandle(); if Refresh then Refresh() end; Print("locked") end)
    NewButton(nil, "Show Ready", 405, -235, 85, 22):SetScript("OnClick", function() DB.showReady = not DB.showReady; if Refresh then Refresh() end; if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Test", 495, -235, 85, 22):SetScript("OnClick", function() testMode = not testMode; if Refresh then Refresh() end; Print("test mode " .. (testMode and "on" or "off")); if f.RefreshText then f.RefreshText() end end)

    NewHeader("Cooldown Numbers", 30, -304)
    NewButton(nil, "Numbers", 30, -327, 85, 22):SetScript("OnClick", function() DB.showTimers = not DB.showTimers; if Refresh then Refresh() end; if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Smaller", 120, -327, 75, 22):SetScript("OnClick", function() SetTimerScaleDelta(-0.15); if Refresh then Refresh() end; if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Bigger", 30, -355, 75, 22):SetScript("OnClick", function() SetTimerScaleDelta(0.15); if Refresh then Refresh() end; if f.RefreshText then f.RefreshText() end end)

    NewHeader("Smart Procs", 215, -304)
    NewButton(nil, "Smart", 215, -327, 65, 22):SetScript("OnClick", function() DB.smartProc = not DB.smartProc; if Refresh then Refresh() end; if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Glow", 285, -327, 65, 22):SetScript("OnClick", function() DB.procGlow = not DB.procGlow; if Refresh then Refresh() end; if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Style", 355, -327, 65, 22):SetScript("OnClick", function() CycleProcGlowStyle(); if Refresh then Refresh() end; if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Pulse", 425, -327, 65, 22):SetScript("OnClick", function() DB.procPulse = not DB.procPulse; if Refresh then Refresh() end; if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Alert", 495, -327, 65, 22):SetScript("OnClick", function() DB.procAlert = not DB.procAlert; if Refresh then Refresh() end; if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Sound", 215, -355, 65, 22):SetScript("OnClick", function() DB.procSound = not DB.procSound; if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Sound Style", 285, -355, 95, 22):SetScript("OnClick", function() CycleProcSoundMode(); TestProcSound(); if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Test Proc", 385, -355, 85, 22):SetScript("OnClick", TestProcVisuals)
    NewButton(nil, "Proc Scan", 475, -355, 85, 22):SetScript("OnClick", PrintProcScan)
    NewButton(nil, "Auto Alert", 110, -355, 85, 22):SetScript("OnClick", function() DB.autoProcAlert = not DB.autoProcAlert; if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Pop Alert", 30, -383, 85, 22):SetScript("OnClick", function() DB.procPopout = not DB.procPopout; if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Hotbars", 120, -383, 75, 22):SetScript("OnClick", function() DB.hotbarGlow = not DB.hotbarGlow; if UpdateHotbarProcHighlights then UpdateHotbarProcHighlights({}) end; if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Test Sound", 215, -383, 95, 22):SetScript("OnClick", function() TestProcSound(); if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Sound Profile", 315, -383, 105, 22):SetScript("OnClick", function() CycleSoundProfile(); TestProcSound(); if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Keybinds", 425, -383, 75, 22):SetScript("OnClick", function() DB.keybindOverlay = not DB.keybindOverlay; if Refresh then Refresh() end; if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Equip +", 505, -383, 75, 22):SetScript("OnClick", function() AddEquipmentSlot(f.input:GetText()); if f.RefreshText then f.RefreshText() end end)

    NewHeader("Proc Filters", 30, -421)
    NewButton(nil, "Ignore Proc", 30, -444, 95, 22):SetScript("OnClick", function() SetProcDisabled(f.input:GetText(), true); if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Allow Proc", 130, -444, 95, 22):SetScript("OnClick", function() SetProcDisabled(f.input:GetText(), false); if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "List Ignored", 230, -444, 95, 22):SetScript("OnClick", ListDisabledProcs)
    NewButton(nil, "Flush Bars", 330, -444, 85, 22):SetScript("OnClick", CacheFlush)

    NewHeader("Profiles / Import / Export", 30, -482)
    NewButton(nil, "Save Profile", 30, -505, 95, 22):SetScript("OnClick", function() SaveProfile(f.input:GetText()); if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Load Profile", 130, -505, 95, 22):SetScript("OnClick", function() LoadProfile(f.input:GetText()); if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Spec Save", 230, -505, 85, 22):SetScript("OnClick", function() SaveProfile(GetSpecProfileName()); if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Spec Load", 320, -505, 85, 22):SetScript("OnClick", function() LoadProfile(GetSpecProfileName()); if f.RefreshText then f.RefreshText() end end)
    NewButton(nil, "Export", 410, -505, 75, 22):SetScript("OnClick", ExportLayout)
    NewButton(nil, "Import", 490, -505, 75, 22):SetScript("OnClick", function() ImportLayout(f.input:GetText()) end)

    f.status = NewStatus(30, -540, 560, 92)

    f.RefreshText = function()
        local lines = {}
        f.sizeLabel:SetText("Icon Size: " .. tostring(DB.iconSize or 36))
        f.colsLabel:SetText("Columns: " .. tostring(DB.maxColumns or 8))
        table.insert(lines, "Ready: " .. (DB.showReady and "ON" or "OFF") .. "   CD Numbers: " .. (DB.showTimers and "ON" or "OFF") .. " (" .. tostring(math.floor((DB.timerScale or 1) * 100 + 0.5)) .. "%)")
        table.insert(lines, "Smart: " .. (DB.smartProc and "ON" or "OFF") .. "   Glow: " .. (DB.procGlow and "ON" or "OFF") .. " style " .. tostring(DB.procGlowStyle or 1) .. "   Pulse: " .. (DB.procPulse and "ON" or "OFF") .. "   Alert: " .. (DB.procAlert and "ON" or "OFF"))
        table.insert(lines, "Sound: " .. (DB.procSound and "ON" or "OFF") .. " profile " .. tostring(DB.soundProfile or "Default") .. "   Auto Alert: " .. (DB.autoProcAlert and "ON" or "OFF") .. "   Pop Alert: " .. (DB.procPopout and "LOUD" or "NORMAL"))
        local ignoredCount = 0
        for k,v in pairs(DB.disabledProcs or {}) do if v then ignoredCount = ignoredCount + 1 end end
        table.insert(lines, "Hotbar Glow: " .. (DB.hotbarGlow and "ON" or "OFF") .. "   Keybinds: " .. (DB.keybindOverlay and "ON" or "OFF") .. "   Ignored Procs: " .. tostring(ignoredCount) .. "   Profile: " .. tostring(DB.activeProfile or "Default"))
        table.insert(lines, "Tracked: " .. tostring(table.getn(DB.spells or {})) .. " spells, " .. tostring(table.getn(DB.items or {})) .. " items, " .. tostring(table.getn(DB.equipmentSlots or {})) .. " equipment, " .. tostring(table.getn(DB.auras or {})) .. " auras")
        if table.getn(DB.spells or {}) > 0 then
            local shown = {}
            for i,v in ipairs(DB.spells) do
                local _, n = GetSpellKey(tostring(v))
                table.insert(shown, tostring(n or v))
                if i >= 6 then table.insert(shown, "..."); break end
            end
            table.insert(lines, "Spells: " .. table.concat(shown, ", "))
        else
            table.insert(lines, "Spells: none")
        end
        f.status:SetText(table.concat(lines, "\n"))
    end

    ConfigFrame = f
    return f
end

local function ToggleConfig()
    local f = CreateConfigFrame()
    if f:IsShown() then f:Hide() else f.RefreshText(); f:Show() end
end


RemoveTrackedObjectByKey = function(objKey)
    if not DB or not objKey then return false end
    local kind, key = tostring(objKey):match("^([^:]+):(.+)$")
    if not kind or not key then return false end

    local list, label
    if kind == "spell" then
        list = DB.spells
        label = "spell"
    elseif kind == "item" then
        list = DB.items
        label = "item"
    elseif kind == "equipment" then
        list = DB.equipmentSlots
        label = "equipment"
    elseif kind == "aura" then
        list = DB.auras
        label = "aura"
    else
        return false
    end

    for i = table.getn(list or {}), 1, -1 do
        local v = list[i]
        local currentKey
        if kind == "spell" then
            currentKey = ObjKey(({ kind = "spell", key = (GetSpellKey(tostring(v))) or v }))
        elseif kind == "item" then
            currentKey = ObjKey(({ kind = "item", key = (GetItemKey(tostring(v))) or v }))
        elseif kind == "equipment" then
            currentKey = "equipment:" .. tostring(v)
        else
            currentKey = "aura:" .. tostring(v)
        end

        if tostring(currentKey) == tostring(objKey) or tostring(v) == tostring(key) or string.lower(tostring(v)) == string.lower(tostring(key)) then
            table.remove(list, i)
            if DB.iconPositions then DB.iconPositions[objKey] = nil end
            NormalizeAddSlotAfterRemoval()
            Print("Removed " .. label .. ": " .. tostring(key))
            if Refresh then Refresh() end
            if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
            return true
        end
    end

    if DB.iconPositions then DB.iconPositions[objKey] = nil end
    NormalizeAddSlotAfterRemoval()
    if Refresh then Refresh() end
    return false
end

local function RemoveFromList(list, input, resolver, label)
    input = Trim(input)
    if input == "" then Print("Usage: /cw remove" .. label .. " <name/id>"); return end
    local removeKey = input
    if resolver then
        local key = resolver(input)
        if key then removeKey = key end
    end
    for i = table.getn(list), 1, -1 do
        if tostring(list[i]) == tostring(removeKey) or string.lower(tostring(list[i])) == string.lower(tostring(input)) then
            local removed = list[i]
            table.remove(list, i)
            if DB and DB.iconPositions then
                DB.iconPositions[label .. ":" .. tostring(removed)] = nil
                DB.iconPositions[label .. ":" .. tostring(removeKey)] = nil
                DB.iconPositions[label .. ":" .. tostring(input)] = nil
            end
            NormalizeAddSlotAfterRemoval()
            Print("Removed " .. label .. ": " .. tostring(input))
            if Refresh then Refresh() end
            if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
            return
        end
    end
    Print("Not found in tracked " .. label .. "s: " .. tostring(input))
end

local function RemoveSpell(input)
    RemoveFromList(DB.spells, input, function(v) local k = GetSpellKey(v); return k end, "spell")
end

local function RemoveItem(input)
    RemoveFromList(DB.items, input, function(v) local k = GetItemKey(v); return k end, "item")
end

local function RemoveAura(input)
    RemoveFromList(DB.auras, input, nil, "aura")
end

local function ListTracked()
    Print("Tracked spells:")
    if table.getn(DB.spells) == 0 then Print("  none") else for i,v in ipairs(DB.spells) do local _, n = GetSpellKey(tostring(v)); Print("  " .. tostring(v) .. (n and (" - " .. n) or "")) end end
    Print("Tracked items:")
    if table.getn(DB.items) == 0 then Print("  none") else for i,v in ipairs(DB.items) do local _, n = GetItemKey(tostring(v)); Print("  " .. tostring(v) .. (n and (" - " .. n) or "")) end end
    Print("Tracked equipment:")
    if table.getn(DB.equipmentSlots or {}) == 0 then Print("  none") else for i,v in ipairs(DB.equipmentSlots or {}) do Print("  " .. EquipmentSlotLabel(v)) end end
    Print("Tracked auras:")
    if table.getn(DB.auras) == 0 then Print("  none") else for i,v in ipairs(DB.auras) do Print("  " .. tostring(v)) end end
end


local function CountProcMap()
    local n = 0
    for _ in pairs(SMART_PROC_MAP or {}) do n = n + 1 end
    return n
end

local function PrintProcLibrary()
    Print("Smart proc library: " .. tostring(CountProcMap()) .. " aura mappings + execute-range pseudo-procs")
    Print("Paladin: Art of War, Infusion of Light, Hammer of Wrath execute")
    Print("Mage: Hot Streak, Missile Barrage, Brain Freeze, Fingers of Frost, Firestarter, Impact, Arcane Potency")
    Print("DK/Warrior/Hunter: Killing Machine, Rime, Sudden Doom, Sudden Death, Bloodsurge, Sword and Board, Lock and Load, Kill Shot execute")
    Print("Shaman/Druid/Priest/Warlock: Maelstrom x5, Tidal Waves, Eclipse, Omen, Surge of Light, Serendipity x3, Nightfall, Molten Core, Decimation, Backdraft")
end

local function PrintProcScan()
    Print("Current proc scan:")
    local found = 0
    for i = 1, 40 do
        local name, _, _, count
        if UnitBuff then name, _, _, count = UnitBuff("player", i) end
        if not name and UnitAura then name, _, _, count = UnitAura("player", i, "HELPFUL") end
        if name then
            local norm = NormalizeProcName(name)
            if SMART_PROC_MAP[string.lower(tostring(name))] or SMART_PROC_MAP[norm] then
                found = found + 1
                Print("  active: " .. tostring(name) .. ((count and count > 0) and (" x" .. tostring(count)) or ""))
            end
        end
    end
    if found == 0 then Print("  no known smart-proc auras currently active") end
    if IsTargetInExecuteRange() then
        Print("  target execute range: yes")
    else
        Print("  target execute range: no")
    end
end



-- Beta50d diagnostics: print what the execute engine and hotbar resolver currently see.
local function DebugHotbar()
    if not RebuildHotbarButtonCache then
        Print("debughotbar unavailable: cache builder missing")
        return
    end
    MarkHotbarCacheDirty()
    RebuildHotbarButtonCache()
    Print("debughotbar: cached buttons = " .. tostring(table.getn(hotbarButtonCache or {})))
    local shown = 0
    local seen = {}
    for _, entry in ipairs(hotbarButtonCache or {}) do
        local b = entry.button
        local name = b and b.GetName and b:GetName() or "<unnamed>"
        local spell = GetActionButtonSpellName(b, entry.slot)
        local key = GetButtonBindingText(b, entry.slot)
        local icon = GetButtonIconTexture(b)
        if spell and not seen[name .. tostring(entry.slot)] then
            seen[name .. tostring(entry.slot)] = true
            shown = shown + 1
            Print("  " .. tostring(shown) .. ". " .. tostring(name) .. " slot=" .. tostring(entry.slot or "?") .. " -> " .. tostring(spell) .. (key and (" [" .. tostring(key) .. "]") or "") .. (icon and " icon=yes" or " icon=no"))
            if shown >= 40 then
                Print("  ...stopped at 40 entries")
                break
            end
        end
    end
    if shown == 0 then Print("  no spell/macro buttons resolved") end
end

local function DebugExecute()
    local hpText = "no target"
    local executeRange = false
    if UnitExists and UnitExists("target") and UnitHealth and UnitHealthMax then
        local maxHealth = UnitHealthMax("target") or 0
        if maxHealth > 0 then
            local pct = ((UnitHealth("target") or 0) / maxHealth) * 100
            hpText = string.format("%.1f%%", pct)
            executeRange = IsTargetInExecuteRange()
        else
            hpText = "target max hp 0"
        end
    end
    local classFile = GetPlayerClassFile() or "?"
    Print("debugexecute: target=" .. hpText .. " class=" .. tostring(classFile) .. " executeRange=" .. (executeRange and "YES" or "NO"))

    local activeProcTargets = BuildActiveProcTargets()
    local activeSpellIcons = BuildActiveSpellIconTargets(activeProcTargets)
    local executeSpells = EXECUTE_SPELLS_BY_CLASS[classFile] or {}
    local any = false
    for _, spellName in ipairs(executeSpells) do
        any = true
        local resolved, icon = ResolveExecuteSpellInfo(spellName)
        local aura = nil
        if resolved then aura = activeProcTargets[string.lower(tostring(resolved))] end
        if not aura then aura = activeProcTargets[string.lower(tostring(spellName))] end
        local matches = 0
        local matchLines = 0
        if hotbarCacheDirty or not hotbarButtonCache then RebuildHotbarButtonCache() end
        for _, entry in ipairs(hotbarButtonCache or {}) do
            local procAura = ResolveHotbarProcAura(entry.button, entry.slot, activeProcTargets, activeSpellIcons)
            if procAura and GetAlertTypeForAura(procAura) == "EXECUTE" then
                matches = matches + 1
                if matchLines < 8 then
                    local b = entry.button
                    local bname = b and b.GetName and b:GetName() or "<unnamed>"
                    local bspell = GetActionButtonSpellName(b, entry.slot) or "?"
                    local key = GetButtonBindingText(b, entry.slot)
                    Print("  execute match: " .. tostring(bname) .. " slot=" .. tostring(entry.slot or "?") .. " spell=" .. tostring(bspell) .. (key and (" [" .. tostring(key) .. "]") or ""))
                    matchLines = matchLines + 1
                end
            end
        end
        Print("  candidate=" .. tostring(spellName) .. " resolved=" .. tostring(resolved or "nil") .. " active=" .. (aura and "YES" or "NO") .. " hotbarMatches=" .. tostring(matches))
    end
    if not any then Print("  no execute spell is registered for this class") end
    Print("  popout option=" .. ((DB and DB.procAlert) and "ON" or "OFF") .. " autoalert=" .. ((DB and DB.autoProcAlert) and "ON" or "OFF") .. " mapSuppress=" .. ((SuppressAlertsForMap and SuppressAlertsForMap()) and "YES" or "NO"))
    Print("  alertCooldowns=" .. tostring(alertCooldowns and "present" or "nil") .. " pending=" .. tostring(pendingProcAlert and "YES" or "NO"))
end

local function CacheFlush()
    ResetSpecSensitiveAlertState()
    MarkHotbarCacheDirty()
    if RebuildHotbarButtonCache then RebuildHotbarButtonCache() end
    if Refresh then Refresh() end
    Print("hotbar/action cache flushed")
end

local function Help()
    Print("/cw config, spellbook, show, hide, lock, unlock, test, ready, timers")
    Print("Unlocked edit mode: drag icons individually. Right-click icon to remove. Shift-drag any icon/+ slot to move the whole group.")
    Print("/cw addspell <name/id>  /cw removespell <name/id>")
    Print("/cw additem <name/id>  /cw removeitem <name/id>")
    Print("/cw addaura <name>  /cw removeaura <name>")
    Print("/cw list  /cw clear  /cw reset  /cw center  /cw release")
    Print("/cw freeform  /cw arrange  /cw snap <pixels>  /cw canvas <w> <h>")
    Print("/cw timers  /cw timersize  /cw proc  /cw procglow  /cw glowstyle  /cw procpulse  /cw procalert  /cw procsound  /cw soundstyle")
    Print("/cw export  /cw import <string>  /cw profile save|load|delete|list <name>  /cw specsave  /cw specload")
    Print("/cw procdebug  /cw proclist  /cw procscan  /cw proctest")
    Print("/cw popout  /cw hotbar - center-screen alert and regular hotbar glow")
    Print("/cw testsound - play the selected proc alert sound")
    Print("/cw soundprofile [minimal|default|loud|pvp|streamer] - set/cycle sound profiles")
    Print("/cw keybinds - toggle keybind overlay on tracked icons and proc alerts")
    Print("/cw equip trinket1|trinket2|gloves - track equipment slots")
    Print("/cw procignore <name>  /cw procallow <name>  /cw proctoggle <name>  /cw procignored  /cw procaudit")
    Print("/cw debughotbar  /cw debugexecute  /cw cacheflush - diagnostics")
end

local function Slash(msg)
    msg = Trim(msg or "")
    local cmd, rest = msg:match("^(%S+)%s*(.-)$")
    cmd = cmd and string.lower(cmd) or ""
    rest = Trim(rest)

    if cmd == "config" or cmd == "options" then
        ToggleConfig()
    elseif cmd == "spellbook" or cmd == "book" then
        OpenSpellbook()
    elseif cmd == "show" then
        DB.enabled = true
        ApplyTrackerVisibility()
        if Refresh then Refresh() end
        Print("shown")
    elseif cmd == "hide" then
        DB.enabled = false
        ForceStopDragging()
        ApplyTrackerVisibility()
        Print("hidden")
    elseif cmd == "lock" then
        DB.locked = true
        ForceStopDragging()
        UpdateDragHandle()
        if dropZone then dropZone:Hide() end
        if Refresh then Refresh() end
        Print("locked")
    elseif cmd == "unlock" then
        DB.locked = false
        DB.freeform = true
        UpdateDragHandle()
        if dropZone then dropZone:Hide() end
        if Refresh then Refresh() end
        Print("designer mode enabled - drag icons individually; shift-drag to move the whole group")
    elseif cmd == "test" then
        testMode = not testMode
        if not testMode then procTestMode = false end
        if Refresh then Refresh() end
        Print("test mode " .. (testMode and "on" or "off"))
    elseif cmd == "ready" or cmd == "showready" then
        DB.showReady = not DB.showReady
        if Refresh then Refresh() end
        Print("show ready icons " .. (DB.showReady and "on" or "off"))
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "timer" or cmd == "timers" or cmd == "numbers" then
        DB.showTimers = not DB.showTimers
        if Refresh then Refresh() end
        Print("cooldown numbers " .. (DB.showTimers and "on" or "off"))
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "proc" or cmd == "smartproc" then
        DB.smartProc = not DB.smartProc
        if Refresh then Refresh() end
        Print("smart proc highlighting " .. (DB.smartProc and "on" or "off"))
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "procglow" or cmd == "glow" then
        DB.procGlow = not DB.procGlow
        if Refresh then Refresh() end
        Print("proc glow " .. (DB.procGlow and "on" or "off"))
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "procpulse" or cmd == "pulse" then
        DB.procPulse = not DB.procPulse
        if Refresh then Refresh() end
        Print("proc pulse " .. (DB.procPulse and "on" or "off"))
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "procalert" or cmd == "alert" then
        DB.procAlert = not DB.procAlert
        if Refresh then Refresh() end
        Print("proc alert overlay " .. (DB.procAlert and "on" or "off"))
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "procsound" or cmd == "sound" then
        DB.procSound = not DB.procSound
        Print("proc sound " .. (DB.procSound and "on" or "off"))
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "soundstyle" or cmd == "procsoundstyle" then
        CycleProcSoundMode()
        TestProcSound()
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "testsound" or cmd == "soundtest" then
        TestProcSound()
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "soundprofile" or cmd == "soundprofiles" or cmd == "soundpreset" then
        if rest and rest ~= "" then ApplySoundProfile(rest) else CycleSoundProfile() end
        TestProcSound()
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "keybinds" or cmd == "keybind" or cmd == "binds" then
        DB.keybindOverlay = not DB.keybindOverlay
        if Refresh then Refresh() end
        Print("keybind overlay " .. (DB.keybindOverlay and "on" or "off"))
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "glowstyle" or cmd == "procstyle" then
        CycleProcGlowStyle()
        if Refresh then Refresh() end
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "timersize" or cmd == "numbersize" then
        local r = string.lower(rest or "")
        if r == "smaller" or r == "small" or r == "down" or r == "-" then
            SetTimerScaleDelta(-0.15)
        elseif r == "bigger" or r == "big" or r == "up" or r == "+" then
            SetTimerScaleDelta(0.15)
        else
            CycleTimerScale()
        end
        if Refresh then Refresh() end
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "proctest" or cmd == "testproc" then
        TestProcVisuals()
    elseif cmd == "autoalert" or cmd == "autoproc" then
        DB.autoProcAlert = not DB.autoProcAlert
        Print("auto proc alerts " .. (DB.autoProcAlert and "on" or "off"))
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "popout" or cmd == "wow" or cmd == "bigproc" then
        DB.procPopout = not DB.procPopout
        Print("large center proc alert " .. (DB.procPopout and "on" or "off"))
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "hotbar" or cmd == "barproc" or cmd == "actionbar" then
        DB.hotbarGlow = not DB.hotbarGlow
        if UpdateHotbarProcHighlights then UpdateHotbarProcHighlights({}) end
        Print("regular hotbar proc glow " .. (DB.hotbarGlow and "on" or "off"))
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "freeform" then
        DB.freeform = true
        if Refresh then Refresh() end
        Print("freeform layout enabled - /cw unlock then drag icons individually")
    elseif cmd == "arrange" then
        DB.iconPositions = {}
        DB.addSlotPosition = { x = 0, y = 0 }
        DB.addSlotAuto = true
        DB.freeform = false
        if Refresh then Refresh() end
        Print("arranged into linear layout")
    elseif cmd == "canvas" then
        local w, h = rest:match("^(%d+)%s+(%d+)$")
        if w and h then
            DB.canvasWidth = tonumber(w)
            DB.canvasHeight = tonumber(h)
            if Refresh then Refresh() end
            Print("canvas set to " .. w .. "x" .. h)
        else
            Print("canvas is " .. tostring(DB.canvasWidth or 600) .. "x" .. tostring(DB.canvasHeight or 400))
        end
    elseif cmd == "snap" then
        local n = tonumber(rest or "")
        if n then
            DB.snap = n
            Print("snap set to " .. tostring(n) .. " pixels")
        else
            Print("snap is " .. tostring(DB.snap or 0) .. " pixels")
        end
    elseif cmd == "procdebug" then
        DB.procDebug = not DB.procDebug
        Print("proc debug " .. (DB.procDebug and "on" or "off"))
    elseif cmd == "proclist" or cmd == "procs" then
        PrintProcLibrary()
    elseif cmd == "procscan" then
        PrintProcScan()
    elseif cmd == "procignore" or cmd == "ignoreproc" or cmd == "disableproc" then
        SetProcDisabled(rest, true)
    elseif cmd == "procallow" or cmd == "allowproc" or cmd == "enableproc" then
        SetProcDisabled(rest, false)
    elseif cmd == "proctoggle" or cmd == "toggleproc" then
        ToggleProcDisabled(rest)
    elseif cmd == "procignored" or cmd == "ignoredprocs" or cmd == "proclistignored" then
        ListDisabledProcs()
    elseif cmd == "procaudit" or cmd == "auditprocs" then
        PrintProcAudit()
    elseif cmd == "debughotbar" or cmd == "bardebug" then
        DebugHotbar()
    elseif cmd == "debugexecute" or cmd == "executedebug" then
        DebugExecute()
    elseif cmd == "cacheflush" or cmd == "flushcache" or cmd == "barflush" then
        CacheFlush()
    elseif cmd == "export" then
        ExportLayout()
    elseif cmd == "import" then
        ImportLayout(rest)
    elseif cmd == "profile" then
        local sub, name = rest:match("^(%S+)%s*(.-)$")
        sub = sub and string.lower(sub) or ""
        name = Trim(name or "")
        if sub == "save" then SaveProfile(name)
        elseif sub == "load" then LoadProfile(name)
        elseif sub == "delete" or sub == "del" then DeleteProfile(name)
        elseif sub == "list" or sub == "" then ListProfiles()
        else Print("Usage: /cw profile save|load|delete|list <name>") end
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "specsave" then
        SaveProfile(GetSpecProfileName())
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "specload" then
        LoadProfile(GetSpecProfileName())
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "grow" then
        local d = string.upper(rest or "")
        if d == "UUP" then d = "UP" end
        if d == "RIGHT" or d == "LEFT" or d == "UP" or d == "DOWN" then
            DB.growDirection = d
            DB.freeform = false
            if Refresh then Refresh() end
            Print("grow direction: " .. d .. " (linear layout)")
        else
            Print("Usage: /cw grow right|left|up|down")
        end
    elseif cmd == "center" then
        DB.point = "CENTER"
        DB.relativePoint = "CENTER"
        DB.x = 0
        DB.y = 0
        ApplyPosition()
        if Refresh then Refresh() end
        Print("centered icon group")
    elseif cmd == "addspell" then
        AddSpell(rest)
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "removespell" or cmd == "delspell" then
        RemoveSpell(rest)
    elseif cmd == "additem" then
        AddItem(rest)
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "removeitem" or cmd == "delitem" then
        RemoveItem(rest)
    elseif cmd == "equip" or cmd == "addequip" or cmd == "addequipment" or cmd == "slot" then
        AddEquipmentSlot(rest)
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "removeequip" or cmd == "delequip" or cmd == "remequip" then
        RemoveEquipmentSlot(rest)
    elseif cmd == "addaura" then
        AddAura(rest)
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "removeaura" or cmd == "delaura" then
        RemoveAura(rest)
    elseif cmd == "list" then
        ListTracked()
    elseif cmd == "clear" then
        DB.spells = {}
        DB.items = {}
        DB.equipmentSlots = {}
        DB.auras = {}
        DB.iconPositions = {}
        DB.addSlotPosition = { x = 0, y = 0 }
        DB.addSlotAuto = true
        if Refresh then Refresh() end
        Print("tracking cleared")
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    elseif cmd == "release" or cmd == "unstick" then
        ForceStopDragging()
        ClearCursor()
        Print("drag/cursor released")
    elseif cmd == "reset" then
        SetDefaults()
        ApplyPosition()
        CW:EnableMouse(false)
        UpdateDragHandle()
        if Refresh then Refresh() end
        Print("reset")
        if ConfigFrame and ConfigFrame.RefreshText then ConfigFrame.RefreshText() end
    else
        Help()
    end
end





AddCursorToTracker = function()
    local cursorType, arg1, arg2
    if GetCursorInfo then
        cursorType, arg1, arg2 = GetCursorInfo()
    end

    if cursorType == "spell" then
        local name
        -- Common Wrath path: spellbook slot + book type.
        if arg1 and arg2 and GetSpellName then
            name = GetSpellName(arg1, arg2)
        end
        -- Some clients expose direct spell ID/name.
        if not name and arg1 then
            name = GetSpellInfo(arg1) or tostring(arg1)
        end
        if not name and arg2 then
            name = GetSpellInfo(arg2) or tostring(arg2)
        end

        if name and name ~= "" then
            AddSpell(tostring(name))
            ClearCursor()
            return true
        end

        Print("Spell drop detected, but the spell name could not be resolved.")
        ClearCursor()
        return false
    elseif cursorType == "item" then
        local item = arg1 or arg2
        if type(item) == "string" then
            local itemId = item:match("item:(%d+)")
            AddItem(tostring(itemId or item))
        elseif item then
            AddItem(tostring(item))
        else
            Print("Item drop detected, but no item data was exposed.")
        end
        ClearCursor()
        return true
    end

    Print("Nothing trackable was dropped. Drag a spell from the spellbook icon or an item from bags/equipment.")
    return false
end



local mapHooksInstalled = false
local function InstallMapAlertHooks()
    if mapHooksInstalled or not WorldMapFrame then return end
    mapHooksInstalled = true
    local oldShow = WorldMapFrame:GetScript("OnShow")
    WorldMapFrame:SetScript("OnShow", function(self, ...)
        if oldShow then oldShow(self, ...) end
        if procAlertFrame and procAlertFrame:IsShown() then HideProcAlertFrame() end
        pendingProcAlert = nil
        if ClearHotbarProcHighlights then ClearHotbarProcHighlights() end
        for _, b in ipairs(buttons or {}) do
            if b.procGlow then b.procGlow:Hide() end
            if b.procText then b.procText:SetText(""); b.procText:Hide(); SafeSetScale(b.procText, 1) end
            if b.timer then b.timer:SetText(""); b.timer:Hide(); SafeSetScale(b.timer, 1) end
            if b.keyText then b.keyText:SetText(""); b.keyText:Hide() end
            if b.timerBG then b.timerBG:Hide() end
        end
        ApplyTrackerVisibility()
    end)
    local oldHide = WorldMapFrame:GetScript("OnHide")
    WorldMapFrame:SetScript("OnHide", function(self, ...)
        if oldHide then oldHide(self, ...) end
        ApplyTrackerVisibility()
        if RequestRefresh then RequestRefresh() end
    end)
end

-- Beta 21: the parent frame is now only an invisible coordinate canvas.
-- It must never capture mouse input; otherwise the 600x400 freeform canvas blocks world clicks.
-- Group movement is handled by Shift-dragging an icon or the + slot instead.
CW:SetMovable(true)
CW:EnableMouse(false)
CW:RegisterForDrag("LeftButton")
CW:SetScript("OnDragStart", nil)
CW:SetScript("OnDragStop", nil)
CW:SetScript("OnMouseDown", nil)
CW:SetScript("OnMouseUp", nil)
CW:SetScript("OnReceiveDrag", nil)


CW:SetScript("OnEvent", function(self, event)
    if event == "ADDON_LOADED" and arg1 == ADDON then
        CoolinatorWrathDB = CopyDefaults(DEFAULTS, CoolinatorWrathDB)
        DB = CoolinatorWrathDB
        NormalizeSavedOptions()
        InstallMapAlertHooks()
        MarkHotbarCacheDirty()
        ApplyPosition()
        UpdateDragHandle()
        if Refresh then Refresh() end
        if dropZone then dropZone:Hide() end
        ApplyTrackerVisibility()
        Print("loaded. Type /cw for commands.")
    elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
        if arg1 == "player" then
            SuppressConsumedProcForSpell(arg2 or arg4 or arg5)
        end
        RequestRefresh()
    elseif event == "ACTIONBAR_SLOT_CHANGED" or event == "ACTIONBAR_PAGE_CHANGED" or event == "UPDATE_BONUS_ACTIONBAR" or event == "ACTIVE_TALENT_GROUP_CHANGED" or event == "PLAYER_TALENT_UPDATE" or event == "CHARACTER_POINTS_CHANGED" then
        ResetSpecSensitiveAlertState()
        RequestRefresh()
    elseif event == "PLAYER_ENTERING_WORLD" or event == "SPELL_UPDATE_COOLDOWN" or event == "ACTIONBAR_UPDATE_COOLDOWN" or event == "BAG_UPDATE_COOLDOWN" or event == "UNIT_AURA" or event == "UNIT_HEALTH" or event == "PLAYER_TARGET_CHANGED" or event == "SPELLS_CHANGED" or event == "CURSOR_UPDATE" or event == "PLAYER_EQUIPMENT_CHANGED" then
        if event == "PLAYER_ENTERING_WORLD" or event == "SPELLS_CHANGED" then MarkHotbarCacheDirty() end
        RequestRefresh()
    end
end)

CW:SetScript("OnUpdate", function(self, elapsed)
    elapsedSinceUpdate = elapsedSinceUpdate + elapsed
    if elapsedSinceUpdate >= 0.20 then
        elapsedSinceUpdate = 0
        if (dragging or draggingButton) and IsMouseButtonDown and not IsMouseButtonDown("LeftButton") then
            ForceStopDragging()
        end
        if SuppressAlertsForMap and SuppressAlertsForMap() then
            if procAlertFrame and procAlertFrame:IsShown() then HideProcAlertFrame() end
            pendingProcAlert = nil
            if ClearHotbarProcHighlights then ClearHotbarProcHighlights() end
            ApplyTrackerVisibility()
        elseif DB and DB.enabled and not CW:IsShown() then
            ApplyTrackerVisibility()
        end
        if refreshQueued then
            refreshQueued = false
            if Refresh then Refresh() end
        else
            UpdateTracker()
        end
        if dropZone then dropZone:Hide() end
    end
end)

CW:RegisterEvent("ADDON_LOADED")
CW:RegisterEvent("PLAYER_ENTERING_WORLD")
CW:RegisterEvent("SPELL_UPDATE_COOLDOWN")
CW:RegisterEvent("ACTIONBAR_UPDATE_COOLDOWN")
CW:RegisterEvent("ACTIONBAR_SLOT_CHANGED")
CW:RegisterEvent("ACTIONBAR_PAGE_CHANGED")
CW:RegisterEvent("UPDATE_BONUS_ACTIONBAR")
CW:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
CW:RegisterEvent("PLAYER_TALENT_UPDATE")
CW:RegisterEvent("CHARACTER_POINTS_CHANGED")
CW:RegisterEvent("SPELLS_CHANGED")
CW:RegisterEvent("BAG_UPDATE_COOLDOWN")
CW:RegisterEvent("UNIT_AURA")
CW:RegisterEvent("UNIT_HEALTH")
CW:RegisterEvent("PLAYER_TARGET_CHANGED")
CW:RegisterEvent("CURSOR_UPDATE")
CW:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
CW:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")

SLASH_COOLINATORWRATH1 = "/cw"
SLASH_COOLINATORWRATH2 = "/coolinatorwrath"
SlashCmdList["COOLINATORWRATH"] = Slash

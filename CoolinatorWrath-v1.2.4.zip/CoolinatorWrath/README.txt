Coolinator-Wrath v1.2.0
Combat Awareness Update

Created by hs0j

Coolinator-Wrath began as a Wrath 3.3.5 backport of the Retail Coolinator addon and has evolved into a complete cooldown, proc, execute, and combat-awareness system built specifically for Wrath clients.

FEATURES

Cooldown Tracking
- Spell cooldowns
- Item cooldowns
- Aura tracking
- Cooldown spirals
- Timer text
- Ready notifications

Smart Proc Engine
Supports Wrath talent and proc interactions across all classes.

Examples:
- Art of War -> Exorcism / Flash of Light
- Infusion of Light -> Holy Light / Flash of Light
- Hot Streak -> Pyroblast
- Missile Barrage -> Arcane Missiles
- Rime -> Howling Blast
- Lock and Load -> Explosive Shot
- Maelstrom Weapon -> Instant casts
- Eclipse -> Starfire / Wrath
- Surge of Light -> Flash Heal / Smite
- Nightfall -> Shadow Bolt

Execute Detection
- Hammer of Wrath
- Execute
- Kill Shot

Alert Categories
- PROC
- BUFF
- EXECUTE

Hotbar Integration
- Action button highlighting
- Macro support
- ElvUI compatibility
- Wrath 3.3.5 compatible action bars

Keybind Overlays
Displays keybinds when available.

Equipment Cooldown Tracking
- Trinket 1
- Trinket 2
- Gloves

Profiles
- Character Profiles
- Spec Profiles
- Import / Export

Freeform Layout System
- Drag-and-drop positioning
- Persistent icon placement
- No forced layouts

Release Status

Coolinator-Wrath is considered feature-complete as a cooldown and combat-awareness addon.

Future development will focus on:
- UI polish
- Sound profile improvements
- Additional profile options
- Wrath compatibility enhancements
- Quality-of-life improvements

Version: 1.2.4
Created by hs0j


1.2.2 changes:
- Fixed stale hotbar USE/EXECUTE overlays after spec/action-bar switching.
- Removed broad frame scanning from the hotbar resolver to avoid ElvUI/private-client clone frames.
- Deduped hotbar proc overlays by resolved spell/icon key so clone buttons do not all light up at once.
- Added per-proc filtering:
  /cw procignore <proc name>
  /cw procallow <proc name>
  /cw proctoggle <proc name>
  /cw procignored
- Added Proc Filters controls to the options window.
- Proc filter choices are saved and included in profiles.


1.2.4 changes:
- Full smart-proc table audit pass.
- Fixed broad utility buffs that could recommend the wrong first spell.
- Omen of Clarity now behaves like Clearcasting: class-aware, no random Regrowth auto-pop.
- Elemental Focus / Clearcasting-style effects are class-aware and no longer auto-pop arbitrary first spells.
- Passive/non-action buffs such as Ancestral Awakening, Holy Concentration, and Improved Spirit Tap are ignored by default.
- Broad haste/utility buffs such as Presence of Mind, Arcane Potency, Nature's Grace, Borrowed Time, and Eradication no longer force center-screen recommendations.
- Added /cw procaudit support command.
